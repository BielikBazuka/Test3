import { MONTHS } from './constants.js'

export const daysInMonth = (m) => new Date(2025, m + 1, 0).getDate()

/**
 * Build raw machine picking demand: 365-element array of { [storage]: picksThisDay }
 */
export function buildDemand(machineTypes, machineStarts, picksPerBuild, workDist, storageTypes) {
  const DAYS = 365
  const demand = Array.from({ length: DAYS }, () => ({}))

  machineTypes.forEach((type) => {
    const dist   = workDist[type]      || []
    const starts = machineStarts[type] || Array(12).fill(0)
    const ppb    = picksPerBuild[type] || {}

    MONTHS.forEach((_, mi) => {
      const count = starts[mi] || 0
      if (!count) return

      dist.forEach((frac, offset) => {
        const tm = mi + offset
        if (tm >= 12) return

        const dc = daysInMonth(tm)
        let dayStart = 0
        for (let m = 0; m < tm; m++) dayStart += daysInMonth(m)

        storageTypes.forEach((s) => {
          const perDay = (count * (ppb[s] || 0) * frac) / dc
          for (let d = 0; d < dc; d++) {
            const di = dayStart + d
            if (di >= DAYS) break
            demand[di][s] = (demand[di][s] || 0) + perDay
          }
        })
      })
    })
  })

  return demand
}

/**
 * Simulate day-by-day with carry-over queue.
 * Capacity priority each day: 1) baseline  2) carried backlog  3) new machine picks
 */
export function simulate(demand, capacity, baseline, storageTypes) {
  const DAYS = demand.length
  const result = Array.from({ length: DAYS }, () => ({
    machinePicks:  {},
    baselinePicks: {},
    carriedIn:     {},
    actual:        {},
    carried:       {},
    overflow:      {},
  }))

  const backlog = Object.fromEntries(storageTypes.map((s) => [s, 0]))

  for (let d = 0; d < DAYS; d++) {
    const r = result[d]
    storageTypes.forEach((s) => {
      const cap     = capacity[s] || 0
      const base    = baseline[s] || 0
      const machDem = demand[d][s] || 0
      const carryIn = backlog[s]

      r.machinePicks[s]  = machDem
      r.baselinePicks[s] = base
      r.carriedIn[s]     = carryIn

      const actualBase    = Math.min(base, cap)
      const capAfterBase  = Math.max(0, cap - actualBase)
      const actualCarry   = Math.min(carryIn, capAfterBase)
      const capAfterCarry = Math.max(0, capAfterBase - actualCarry)
      const actualMach    = Math.min(machDem, capAfterCarry)

      r.actual[s]   = actualBase + actualCarry + actualMach
      r.carried[s]  = (machDem - actualMach) + (carryIn - actualCarry)
      r.overflow[s] = r.carried[s] > 0
      backlog[s]    = r.carried[s]
    })
  }

  return result
}
