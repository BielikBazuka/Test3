import { useMemo } from 'react'
import { MONTHS } from '../constants.js'
import { daysInMonth } from '../simulation.js'

// ── helpers ───────────────────────────────────────────────────────────────────

function dayLabel(dayIndex) {
  let rem = dayIndex
  for (let m = 0; m < 12; m++) {
    const dm = daysInMonth(m)
    if (rem < dm) return `${MONTHS[m]} ${rem + 1}`
    rem -= dm
  }
  return 'Dec 31'
}

// ── KPI card ──────────────────────────────────────────────────────────────────

function Kpi({ label, value, sub, color }) {
  return (
    <div className="kpi" style={{ borderTopColor: color || 'var(--blue)' }}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value" style={{ color: color || 'var(--text)' }}>{value}</div>
      <div className="kpi-sub">{sub}</div>
    </div>
  )
}

// ── Bar chart ─────────────────────────────────────────────────────────────────

function BarChart({ viewResult, dayOffset, selectedDay, setSelectedDay, storageTypes, storageColorMap, totalCap, maxStack, setTooltip }) {
  const H = 200
  return (
    <div className="chart-wrap">
      <div style={{ position: 'relative', height: H + 4 }}>
        {[0.25, 0.5, 0.75, 1].map((f) => (
          <div key={f} className="grid-line" style={{ top: H * (1 - f) }}>
            <span className="grid-lbl">{Math.round(maxStack * f).toLocaleString()}</span>
          </div>
        ))}
        <div className="cap-line" style={{ top: H * (1 - Math.min(totalCap / maxStack, 1)) }}>
          <span className="cap-lbl">Cap {totalCap.toLocaleString()}</span>
        </div>
        <div className="bar-area" style={{ position: 'absolute', inset: 0 }}>
          {viewResult.map((d, i) => {
            const abs     = dayOffset + i
            const isSel   = abs === selectedDay
            const machT   = storageTypes.reduce((a, s) => a + (d.machinePicks[s]  || 0), 0)
            const baseT   = storageTypes.reduce((a, s) => a + (d.baselinePicks[s] || 0), 0)
            const carryT  = storageTypes.reduce((a, s) => a + (d.carriedIn[s]     || 0), 0)
            const carryOut= storageTypes.reduce((a, s) => a + (d.carried[s]       || 0), 0)
            return (
              <div
                key={i}
                className={`b-wrap ${isSel ? 'sel' : ''}`}
                onClick={() => setSelectedDay(abs)}
                onMouseMove={(e) => setTooltip({
                  x: e.clientX, y: e.clientY,
                  title: `Day ${abs + 1} — ${dayLabel(abs)}`,
                  rows: [
                    ['Machine picks', Math.round(machT).toLocaleString(), ''],
                    ['Baseline picks', Math.round(baseT).toLocaleString(), ''],
                    ['Carried in', Math.round(carryT).toLocaleString(), carryT > 0 ? 'warn' : ''],
                    ['Capacity', totalCap.toLocaleString(), ''],
                    ['Carried out', Math.round(carryOut).toLocaleString(), carryOut > 0 ? 'warn' : 'ok'],
                  ],
                })}
                onMouseLeave={() => setTooltip(null)}
              >
                {storageTypes.map((s) => {
                  const v = d.machinePicks[s] || 0
                  if (!v) return null
                  return (
                    <div key={s} className="b-seg" style={{ height: (v / maxStack) * H, background: storageColorMap[s], opacity: isSel ? 1 : 0.78 }} />
                  )
                })}
                {baseT > 0 && <div className="b-base" style={{ height: (baseT / maxStack) * H, backgroundColor: 'var(--amber)' }} />}
                {carryT > 0 && <div className="b-carry" style={{ height: (carryT / maxStack) * H }} />}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ── Heat map ──────────────────────────────────────────────────────────────────

function HeatMap({ result, totalCap, selectedDay, setSelectedDay, setTooltip, storageTypes, dailyCarried }) {
  const weeks = Array.from({ length: 53 }, (_, w) =>
    Array.from({ length: 7 }, (_, d) => { const idx = w * 7 + d; return idx < 365 ? idx : null })
  )
  const maxAct = Math.max(...result.map((d) => storageTypes.reduce((a, s) => a + (d.actual[s] || 0), 0)), 1)
  const maxBl  = Math.max(...dailyCarried, 1)
  const days   = ['M', 'T', 'W', 'T', 'F', 'S', 'S']

  return (
    <div className="hm-wrap">
      <div className="hm-grid">
        <div />
        {weeks.map((_, w) => <div key={w} className="hm-week-lbl">{w % 4 === 0 ? `W${w + 1}` : ''}</div>)}
        {days.map((dn, di) => (
          <>
            <div key={`l${di}`} className="hm-row-lbl">{dn}</div>
            {weeks.map((week, wi) => {
              const idx = week[di]
              if (idx === null) return <div key={`e${wi}`} style={{ width: 13, height: 13 }} />
              const act  = storageTypes.reduce((a, s) => a + (result[idx].actual[s] || 0), 0)
              const bl   = dailyCarried[idx] || 0
              const pct  = act / maxAct
              const isSel = idx === selectedDay
              const bg = bl > 0
                ? `rgba(222,53,11,${0.15 + Math.min(bl / maxBl, 1) * 0.75})`
                : `rgba(0,128,201,${0.07 + pct * 0.86})`
              return (
                <div
                  key={`d${wi}${di}`}
                  className="hm-cell"
                  style={{ background: bg, border: isSel ? '2px solid var(--blue)' : '1px solid transparent' }}
                  onClick={() => setSelectedDay(idx)}
                  onMouseMove={(e) => setTooltip({
                    x: e.clientX, y: e.clientY,
                    title: `Day ${idx + 1} — ${dayLabel(idx)}`,
                    rows: [
                      ['Processed', Math.round(act).toLocaleString(), ''],
                      ['Backlog out', Math.round(bl).toLocaleString(), bl > 0 ? 'warn' : 'ok'],
                    ],
                  })}
                  onMouseLeave={() => setTooltip(null)}
                />
              )
            })}
          </>
        ))}
      </div>
    </div>
  )
}

// ── Backlog chart ─────────────────────────────────────────────────────────────

function BacklogChart({ dailyCarried, selectedDay, setSelectedDay, setTooltip }) {
  const maxBl = Math.max(...dailyCarried, 1)
  return (
    <div className="bl-wrap">
      <div className="bl-bars">
        {dailyCarried.map((v, i) => {
          const h = Math.max((v / maxBl) * 72, v > 0 ? 1 : 0)
          const isSel = i === selectedDay
          return (
            <div
              key={i}
              className="bl-bar"
              style={{
                height: h,
                background: v > 0 ? 'var(--amber)' : 'var(--border)',
                opacity: isSel ? 1 : v > 0 ? 0.7 : 0.35,
                outline: isSel ? '1.5px solid var(--blue)' : undefined,
              }}
              onClick={() => setSelectedDay(i)}
              onMouseMove={(e) => setTooltip({
                x: e.clientX, y: e.clientY,
                title: `Day ${i + 1} Backlog`,
                rows: [['Carried out', Math.round(v).toLocaleString(), v > 0 ? 'warn' : 'ok']],
              })}
              onMouseLeave={() => setTooltip(null)}
            />
          )
        })}
      </div>
    </div>
  )
}

// ── Monthly table ─────────────────────────────────────────────────────────────

function MonthlyTable({ result, storageTypes, totalCap, machineTypes, machineStarts, dailyCarried }) {
  const data = useMemo(() =>
    MONTHS.map((m, mi) => {
      let s = 0
      for (let i = 0; i < mi; i++) s += daysInMonth(i)
      const slice   = result.slice(s, s + daysInMonth(mi))
      const blSlice = dailyCarried.slice(s, s + daysInMonth(mi))
      const demand     = slice.reduce((a, d) => a + storageTypes.reduce((x, st) => x + (d.machinePicks[st] || 0) + (d.baselinePicks[st] || 0), 0), 0)
      const processed  = slice.reduce((a, d) => a + storageTypes.reduce((x, st) => x + (d.actual[st] || 0), 0), 0)
      const peakBl     = Math.max(...blSlice, 0)
      const blDays     = blSlice.filter((v) => v > 0).length
      const starts     = machineTypes.reduce((a, t) => a + ((machineStarts[t] || [])[mi] || 0), 0)
      return { m, demand, processed, peakBl, blDays, starts }
    }),
  [result, storageTypes, totalCap, dailyCarried, machineTypes, machineStarts])

  const maxDemand = Math.max(...data.map((d) => d.demand), 1)

  return (
    <div style={{ overflowX: 'auto' }}>
      <table className="m-table">
        <thead>
          <tr>
            {['Month', 'Starts', 'Demand', 'Processed', 'Peak Backlog', 'Backlog Days', 'Workload'].map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              <td style={{ fontWeight: 600, color: 'var(--blue)' }}>{row.m}</td>
              <td style={{ fontFamily: 'var(--mono)', color: row.starts > 0 ? 'var(--text)' : 'var(--text-dim)' }}>{row.starts}</td>
              <td style={{ fontFamily: 'var(--mono)' }}>{Math.round(row.demand).toLocaleString()}</td>
              <td style={{ fontFamily: 'var(--mono)' }}>{Math.round(row.processed).toLocaleString()}</td>
              <td><span className={`badge ${row.peakBl > 0 ? 'badge-amber' : 'badge-ok'}`}>{row.peakBl > 0 ? Math.round(row.peakBl).toLocaleString() : '—'}</span></td>
              <td><span className={`badge ${row.blDays > 0 ? 'badge-warn' : 'badge-ok'}`}>{row.blDays > 0 ? `${row.blDays}d` : 'None'}</span></td>
              <td style={{ minWidth: 110 }}>
                <div className="wl-track">
                  <div className="wl-fill" style={{ width: `${(row.demand / maxDemand) * 100}%`, background: row.blDays > 0 ? 'var(--warn)' : 'var(--blue)' }} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── Main ──────────────────────────────────────────────────────────────────────

export default function SimView({
  result, storageTypes, capacity, baseline, storageColorMap,
  machineTypes, machineStarts,
  selectedDay, setSelectedDay, viewMode, setViewMode,
  selMonth, setSelMonth, setTooltip,
}) {
  const totalCap    = storageTypes.reduce((a, s) => a + (capacity[s] || 0), 0)
  const dailyActual = useMemo(() => result.map((d) => storageTypes.reduce((a, s) => a + (d.actual[s]  || 0), 0)), [result, storageTypes])
  const dailyCarried= useMemo(() => result.map((d) => storageTypes.reduce((a, s) => a + (d.carried[s] || 0), 0)), [result, storageTypes])

  const peakActual  = useMemo(() => { let mx = 0, idx = 0; dailyActual.forEach((v, i) => { if (v > mx) { mx = v; idx = i } }); return { val: Math.round(mx), day: idx } }, [dailyActual])
  const maxBacklog  = useMemo(() => Math.max(...dailyCarried, 0), [dailyCarried])
  const backlogDays = useMemo(() => dailyCarried.filter((v) => v > 0).length, [dailyCarried])
  const avgActual   = useMemo(() => Math.round(dailyActual.reduce((a, b) => a + b, 0) / 365), [dailyActual])
  const totalStarts = machineTypes.reduce((a, t) => a + (machineStarts[t] || []).reduce((x, y) => x + y, 0), 0)

  const viewResult  = useMemo(() => {
    if (selMonth === null) return result
    let s = 0; for (let m = 0; m < selMonth; m++) s += daysInMonth(m)
    return result.slice(s, s + daysInMonth(selMonth))
  }, [result, selMonth])

  const dayOffset = useMemo(() => {
    if (selMonth === null) return 0
    let s = 0; for (let m = 0; m < selMonth; m++) s += daysInMonth(m); return s
  }, [selMonth])

  const maxStack = useMemo(() =>
    Math.max(
      ...viewResult.map((d) => storageTypes.reduce((a, s) => a + (d.machinePicks[s] || 0) + (d.baselinePicks[s] || 0) + (d.carriedIn[s] || 0), 0)),
      totalCap, 1
    ), [viewResult, storageTypes, totalCap])

  const dayData      = result[selectedDay] || { actual: {}, machinePicks: {}, baselinePicks: {}, carriedIn: {}, carried: {}, overflow: {} }
  const dayActual    = storageTypes.reduce((a, s) => a + (dayData.actual[s]    || 0), 0)
  const dayCarriedIn = storageTypes.reduce((a, s) => a + (dayData.carriedIn[s] || 0), 0)
  const dayCarriedOut= storageTypes.reduce((a, s) => a + (dayData.carried[s]   || 0), 0)
  const hasOverflow  = storageTypes.some((s) => dayData.overflow[s])
  const dateStr      = dayLabel(selectedDay)

  return (
    <div>
      {/* KPIs */}
      <div className="kpi-strip">
        <Kpi label="Machine Starts"    value={totalStarts}                    sub="across all types" />
        <Kpi label="Peak Daily Actual" value={peakActual.val.toLocaleString()} sub={`Day ${peakActual.day + 1} · cap ${totalCap.toLocaleString()}`} color={peakActual.val > totalCap ? 'var(--warn)' : 'var(--ok)'} />
        <Kpi label="Avg Daily Picks"   value={avgActual.toLocaleString()}      sub="actually processed/day" />
        <Kpi label="Days with Backlog" value={backlogDays}                     sub={`of 365 (${Math.round(backlogDays / 3.65)}%)`} color={backlogDays > 0 ? 'var(--warn)' : 'var(--ok)'} />
        <Kpi label="Peak Backlog"      value={Math.round(maxBacklog).toLocaleString()} sub="picks carried at once" color={maxBacklog > 0 ? 'var(--amber)' : 'var(--ok)'} />
      </div>

      {/* Timeline */}
      <div className="tl-card">
        <div className="tl-controls">
          <div className="ctrl-group">
            <span className="ctrl-label">View</span>
            <div className="view-btns">
              <button className={`vbtn ${viewMode === 'bar'  ? 'active' : ''}`} onClick={() => setViewMode('bar')}>Bar</button>
              <button className={`vbtn ${viewMode === 'heat' ? 'active' : ''}`} onClick={() => setViewMode('heat')}>Heat</button>
            </div>
          </div>
          <div className="ctrl-group" style={{ flexWrap: 'wrap' }}>
            <span className="ctrl-label">Month</span>
            <div className="month-pills">
              <button className={`mpill ${selMonth === null ? 'active' : ''}`} onClick={() => setSelMonth(null)}>All</button>
              {MONTHS.map((m, i) => (
                <button key={m} className={`mpill ${selMonth === i ? 'active' : ''}`} onClick={() => setSelMonth(i)}>{m}</button>
              ))}
            </div>
          </div>
          <div className="ctrl-group" style={{ marginLeft: 'auto' }}>
            <span className="ctrl-label">Day</span>
            <input className="day-slider" type="range" min="0" max="364" value={selectedDay}
              onChange={(e) => setSelectedDay(parseInt(e.target.value))} />
            <span className="day-display">{dateStr}</span>
          </div>
        </div>

        {viewMode === 'bar'
          ? <BarChart viewResult={viewResult} dayOffset={dayOffset} selectedDay={selectedDay} setSelectedDay={setSelectedDay}
              storageTypes={storageTypes} storageColorMap={storageColorMap} totalCap={totalCap} maxStack={maxStack} setTooltip={setTooltip} />
          : <HeatMap result={result} totalCap={totalCap} selectedDay={selectedDay} setSelectedDay={setSelectedDay}
              setTooltip={setTooltip} storageTypes={storageTypes} dailyCarried={dailyCarried} />
        }

        {/* Legend */}
        <div className="legend">
          {storageTypes.map((s) => (
            <div key={s} className="leg-item">
              <div className="leg-dot" style={{ background: storageColorMap[s] }} />{s}
            </div>
          ))}
          <div className="leg-item"><div className="leg-hatch" />Baseline tasks</div>
          <div className="leg-item">
            <div className="leg-hatch" style={{ background: 'repeating-linear-gradient(-45deg,var(--warn),var(--warn) 2px,rgba(255,255,255,.3) 2px,rgba(255,255,255,.3) 4px)' }} />
            Carried backlog
          </div>
          <div className="leg-item"><div className="leg-line" style={{ background: 'var(--warn)' }} />Capacity limit</div>
        </div>

        {/* Day detail */}
        <div className="day-detail">
          <div className="detail-col">
            <div className="detail-title">Storage Utilisation — {dateStr}</div>
            {storageTypes.map((s) => {
              const act   = dayData.actual[s]  || 0
              const cap   = capacity[s]         || 1
              const carry = dayData.carried[s]  || 0
              const pct   = Math.min(act / cap, 1)
              const over  = dayData.overflow[s]
              return (
                <div key={s} className="util-row">
                  <div className="util-lbl" style={{ color: over ? 'var(--warn)' : storageColorMap[s] }}>{s}</div>
                  <div className="util-track">
                    <div className="util-fill" style={{ width: `${pct * 100}%`, background: over ? 'var(--warn)' : storageColorMap[s] }} />
                  </div>
                  <div className="util-pct" style={{ color: over ? 'var(--warn)' : 'var(--ok)' }}>{Math.round(pct * 100)}%</div>
                  <div className="util-abs">
                    {Math.round(act).toLocaleString()} / {cap.toLocaleString()}
                    {carry > 0 && <span style={{ color: 'var(--amber)', marginLeft: 3 }}>+{Math.round(carry).toLocaleString()}→</span>}
                  </div>
                </div>
              )
            })}
          </div>
          <div className="detail-col">
            <div className="detail-title">Daily Summary — {dateStr}</div>
            {[
              ['Machine picks demanded',   Math.round(storageTypes.reduce((a, s) => a + (dayData.machinePicks[s]  || 0), 0)).toLocaleString(), ''],
              ['Baseline picks',           Math.round(storageTypes.reduce((a, s) => a + (dayData.baselinePicks[s] || 0), 0)).toLocaleString(), ''],
              ['Carried in from yesterday',Math.round(dayCarriedIn).toLocaleString(),  dayCarriedIn  > 0 ? 'warn' : ''],
              ['Actually processed',       Math.round(dayActual).toLocaleString(),     ''],
              ['Carried to tomorrow',      Math.round(dayCarriedOut).toLocaleString(), dayCarriedOut > 0 ? 'warn' : 'ok'],
              ['Total capacity',           totalCap.toLocaleString(),                  ''],
              ['Status', hasOverflow ? '⚠ Capacity Exceeded' : '✓ Within Capacity',  hasOverflow ? 'warn' : 'ok'],
            ].map(([k, v, c]) => (
              <div key={k} className="sum-row">
                <span className="sum-key">{k}</span>
                <span className="sum-val" style={{ color: c === 'warn' ? 'var(--warn)' : c === 'ok' ? 'var(--ok)' : undefined }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Backlog over time */}
      <div className="card card-accent" style={{ marginBottom: 18 }}>
        <div className="card-header">
          <div>
            <div className="card-title">Carry-over Backlog Over Time</div>
            <div className="card-subtitle">Picks rolled to the next day — total across all storages</div>
          </div>
          <span className={`badge ${maxBacklog > 0 ? 'badge-warn' : 'badge-ok'}`}>
            {maxBacklog > 0 ? `Peak: ${Math.round(maxBacklog).toLocaleString()} picks` : 'No backlog'}
          </span>
        </div>
        <BacklogChart dailyCarried={dailyCarried} selectedDay={selectedDay} setSelectedDay={setSelectedDay} setTooltip={setTooltip} />
      </div>

      {/* Monthly overview */}
      <div className="m-table-card">
        <div className="card-header"><div className="card-title">Monthly Overview</div></div>
        <MonthlyTable result={result} storageTypes={storageTypes} totalCap={totalCap}
          machineTypes={machineTypes} machineStarts={machineStarts} dailyCarried={dailyCarried} />
      </div>
    </div>
  )
}
