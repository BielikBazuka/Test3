const css = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

:root{
  --blue:#0080c9;
  --blue-dark:#005fa3;
  --blue-light:#e6f3fb;
  --bg:#f4f6f9;
  --bg-white:#ffffff;
  --panel:#ffffff;
  --border:#d0dae6;
  --border-dark:#a8bdd0;
  --text:#1a2533;
  --text-mid:#4a6080;
  --text-dim:#7a95b0;
  --ok:#00875a;
  --ok-bg:#e3fcef;
  --warn:#de350b;
  --warn-bg:#ffebe6;
  --amber:#ff8b00;
  --amber-bg:#fffae6;
  --font:'Inter',sans-serif;
  --mono:'JetBrains Mono',monospace;
  --radius:6px;
  --shadow:0 1px 4px rgba(0,40,80,.10),0 0 0 1px rgba(0,40,80,.05);
  --shadow-lg:0 4px 16px rgba(0,40,80,.12),0 0 0 1px rgba(0,40,80,.06);
}

body{background:var(--bg);color:var(--text);font-family:var(--font);font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}

/* Layout */
.layout{display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--blue-dark);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.main{flex:1;overflow:auto;min-width:0}

/* Sidebar */
.sb-logo{padding:22px 18px 18px;border-bottom:1px solid rgba(255,255,255,.1)}
.sb-title{font-size:19px;font-weight:700;letter-spacing:1px;color:#fff}
.sb-sub{font-size:9px;font-weight:500;letter-spacing:2.5px;color:rgba(255,255,255,.45);margin-top:4px;text-transform:uppercase}
.sb-nav{padding:10px 0;flex:1}
.sb-section{padding:8px 18px 3px;font-size:9px;font-weight:600;letter-spacing:2px;color:rgba(255,255,255,.3);text-transform:uppercase}
.sb-item{display:flex;align-items:center;gap:9px;padding:9px 18px;cursor:pointer;font-size:13px;font-weight:500;color:rgba(255,255,255,.65);transition:all .15s;border-left:3px solid transparent}
.sb-item:hover{background:rgba(255,255,255,.07);color:#fff}
.sb-item.active{background:rgba(255,255,255,.11);color:#fff;border-left-color:#fff}
.sb-icon{font-size:14px;width:18px;text-align:center}
.sb-footer{padding:14px 18px;border-top:1px solid rgba(255,255,255,.1);font-size:10px;color:rgba(255,255,255,.3);line-height:1.9}

/* Topbar */
.topbar{background:#fff;border-bottom:1px solid var(--border);padding:0 26px;height:54px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.topbar-title{font-size:15px;font-weight:600}
.topbar-right{display:flex;align-items:center;gap:14px}
.status-pill{display:flex;align-items:center;gap:5px;padding:3px 9px;border-radius:12px;font-size:11px;font-weight:500;background:var(--ok-bg);color:var(--ok)}
.status-dot{width:6px;height:6px;border-radius:50%;background:currentColor;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.topbar-time{font-family:var(--mono);font-size:11px;color:var(--text-dim)}

/* Content */
.content{padding:22px 26px 60px}

/* Card */
.card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow)}
.card-accent{border-top:2px solid var(--blue)}
.card-header{padding:13px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px}
.card-title{font-size:11px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text)}
.card-subtitle{font-size:11px;color:var(--text-dim);font-weight:400;margin-top:1px}
.card-body{padding:18px}

/* Section */
.section{margin-bottom:18px}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.section-label{font-size:11px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-mid);display:flex;align-items:center;gap:7px}
.section-label::before{content:'';display:inline-block;width:3px;height:13px;background:var(--blue);border-radius:2px}

/* KPI strip */
.kpi-strip{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:18px}
.kpi{background:var(--panel);border:1px solid var(--border);border-top:3px solid var(--border);border-radius:var(--radius);padding:14px 16px;box-shadow:var(--shadow)}
.kpi-label{font-size:9px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-dim);margin-bottom:5px}
.kpi-value{font-size:24px;font-weight:700;line-height:1}
.kpi-sub{font-size:10px;color:var(--text-dim);margin-top:3px}

/* Storage config */
.storage-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
.storage-row{display:flex;align-items:center;gap:9px;padding:7px 11px;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);transition:border-color .15s}
.storage-row:focus-within{border-color:var(--blue)}
.s-dot{width:10px;height:10px;border-radius:2px;flex-shrink:0}
.s-name{flex:1;min-width:0;background:transparent;border:none;outline:none;font-family:var(--font);font-size:13px;font-weight:500;color:var(--text)}
.s-cap{width:72px;text-align:right;background:#fff;border:1px solid var(--border);border-radius:4px;padding:3px 6px;font-family:var(--mono);font-size:12px;color:var(--text);outline:none;transition:border-color .15s}
.s-cap:focus{border-color:var(--blue)}
.s-unit{font-size:10px;color:var(--text-dim);white-space:nowrap}

/* Matrix table */
.matrix-wrap{overflow-x:auto}
.matrix{width:100%;border-collapse:collapse}
.matrix th{font-size:9px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-dim);text-align:left;padding:8px 10px;border-bottom:2px solid var(--border);background:var(--bg);white-space:nowrap}
.matrix th.st-th{text-align:right;border-bottom-color:var(--blue)}
.matrix td{padding:5px 10px;border-bottom:1px solid var(--border);vertical-align:middle}
.matrix tr:last-child td{border-bottom:none}
.matrix tbody tr:hover td{background:var(--blue-light)}
.m-cell{display:flex;align-items:center;gap:9px}
.m-icon{font-size:15px;width:20px;text-align:center}
.m-name{font-family:var(--font);font-size:13px;font-weight:600;background:transparent;border:none;border-bottom:1px solid transparent;outline:none;min-width:0;width:85px;transition:border-color .15s;cursor:text}
.m-name:focus{border-bottom-color:var(--blue)}
.picks{width:86px;text-align:right;background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:4px 7px;font-family:var(--mono);font-size:12px;color:var(--text);outline:none;display:block;transition:border-color .15s,background .15s}
.picks:focus,.picks.filled{background:#fff}
.picks:focus{border-color:var(--blue)}
.total-num{font-family:var(--mono);font-size:12px;font-weight:700;color:var(--blue);text-align:right}
.mini-bar{height:3px;border-radius:2px;margin-top:3px;margin-left:auto}
.baseline-input{width:86px;text-align:right;background:var(--bg);border:1px solid var(--amber);border-radius:4px;padding:4px 7px;font-family:var(--mono);font-size:12px;color:var(--text);outline:none;display:block;transition:background .15s}
.baseline-input:focus{background:#fff}

/* Starts grid */
.starts-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.start-card{background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.start-card-hdr{padding:8px 13px;display:flex;align-items:center;gap:7px;border-bottom:1px solid var(--border);border-left:3px solid transparent}
.month-row{display:grid;grid-template-columns:repeat(12,1fr);gap:3px;padding:9px 11px}
.m-cell-wrap{display:flex;flex-direction:column;align-items:center;gap:2px}
.m-lbl{font-size:8px;font-weight:600;letter-spacing:.3px;text-transform:uppercase;color:var(--text-dim)}
.m-inp{width:100%;text-align:center;background:#fff;border:1px solid var(--border);border-radius:3px;padding:3px 1px;font-family:var(--mono);font-size:12px;color:var(--text);outline:none;transition:border-color .15s,box-shadow .15s}
.m-inp:focus{border-color:var(--blue);box-shadow:0 0 0 2px var(--blue-light)}
.m-inp.filled{font-weight:600}

/* Distribution */
.dist-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.dist-card{background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.dist-hdr{padding:8px 13px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:8px;border-left:3px solid transparent}
.dist-row{display:flex;align-items:center;gap:7px;padding:4px 13px}
.dist-lbl{font-size:10px;color:var(--text-dim);width:54px;flex-shrink:0;font-family:var(--mono)}
.dist-track{flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden}
.dist-fill{height:100%;border-radius:3px;transition:width .3s}
.dist-inp{width:50px;text-align:center;background:#fff;border:1px solid var(--border);border-radius:3px;padding:3px 4px;font-family:var(--mono);font-size:11px;color:var(--text);outline:none}
.dist-inp:focus{border-color:var(--blue)}
.dist-sum{font-size:11px;font-weight:600;font-family:var(--mono)}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:5px;cursor:pointer;font-family:var(--font);font-weight:500;border-radius:4px;transition:all .15s;border:1px solid transparent;font-size:12px;padding:5px 13px}
.btn-primary{background:var(--blue);color:#fff;border-color:var(--blue)}
.btn-primary:hover{background:var(--blue-dark)}
.btn-outline{background:transparent;color:var(--blue);border-color:var(--blue)}
.btn-outline:hover{background:var(--blue-light)}
.btn-ghost{background:transparent;color:var(--text-dim);border-color:var(--border)}
.btn-ghost:hover{background:var(--bg);color:var(--text)}
.btn-danger{background:transparent;color:var(--warn);border-color:rgba(222,53,11,.3)}
.btn-danger:hover{background:var(--warn-bg)}
.btn-del{background:none;border:none;color:var(--text-dim);cursor:pointer;padding:2px 5px;font-size:13px;border-radius:3px;transition:color .15s}
.btn-del:hover{color:var(--warn)}
.run-btn{display:flex;align-items:center;justify-content:center;gap:9px;width:100%;max-width:300px;margin:26px auto;background:var(--blue);color:#fff;font-family:var(--font);font-size:14px;font-weight:600;padding:12px 28px;border:none;border-radius:var(--radius);cursor:pointer;letter-spacing:.3px;box-shadow:0 2px 8px rgba(0,128,201,.3);transition:all .2s}
.run-btn:hover{background:var(--blue-dark);box-shadow:0 4px 16px rgba(0,128,201,.4);transform:translateY(-1px)}

/* Timeline card */
.tl-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);margin-bottom:18px;overflow:hidden}
.tl-controls{padding:11px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;flex-wrap:wrap;background:var(--bg)}
.ctrl-label{font-size:9px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-dim)}
.ctrl-group{display:flex;align-items:center;gap:6px}
.view-btns{display:flex;border:1px solid var(--border);border-radius:4px;overflow:hidden}
.vbtn{font-size:11px;padding:4px 10px;border:none;background:transparent;cursor:pointer;color:var(--text-dim);transition:all .15s;font-weight:500}
.vbtn.active{background:var(--blue);color:#fff}
.vbtn:hover:not(.active){background:var(--blue-light);color:var(--blue)}
.month-pills{display:flex;gap:3px;flex-wrap:wrap}
.mpill{font-size:9px;padding:3px 7px;border-radius:10px;border:1px solid var(--border);background:transparent;cursor:pointer;color:var(--text-dim);transition:all .15s;font-weight:500}
.mpill.active{background:var(--blue);color:#fff;border-color:var(--blue)}
.mpill:hover:not(.active){border-color:var(--blue);color:var(--blue)}
.day-slider{accent-color:var(--blue);flex:1;min-width:130px}
.day-display{font-family:var(--mono);font-size:12px;color:var(--blue);font-weight:500;min-width:84px}

/* Bar chart */
.chart-wrap{padding:14px 18px;overflow:auto}
.bar-area{display:flex;align-items:flex-end;gap:1px;height:200px;position:relative;cursor:crosshair}
.b-wrap{flex:1;display:flex;flex-direction:column;justify-content:flex-end;height:100%;cursor:pointer;position:relative}
.b-wrap:hover .b-seg{filter:brightness(1.12)}
.b-wrap.sel .b-seg{filter:brightness(1.2)}
.b-wrap.sel::after{content:'';position:absolute;inset:0;border:1px solid rgba(0,128,201,.5);border-radius:1px;pointer-events:none}
.b-seg{width:100%;min-height:1px}
.b-base{width:100%;min-height:1px;background:repeating-linear-gradient(45deg,transparent,transparent 2px,rgba(0,0,0,.15) 2px,rgba(0,0,0,.15) 4px)}
.b-carry{width:100%;min-height:1px;background:repeating-linear-gradient(-45deg,transparent,transparent 2px,rgba(255,255,255,.3) 2px,rgba(255,255,255,.3) 4px);background-color:var(--warn)}
.cap-line{position:absolute;left:0;right:0;border-top:1.5px dashed var(--warn);z-index:3;pointer-events:none}
.cap-lbl{position:absolute;right:0;top:-15px;font-size:9px;font-weight:600;color:var(--warn);font-family:var(--mono)}
.grid-line{position:absolute;left:0;right:0;border-top:1px solid var(--border);pointer-events:none}
.grid-lbl{position:absolute;left:0;top:-9px;font-size:9px;color:var(--text-dim);font-family:var(--mono)}

/* Heatmap */
.hm-wrap{overflow:auto;padding:10px 18px 14px}
.hm-grid{display:grid;grid-template-columns:78px repeat(53,13px);gap:2px;align-items:center}
.hm-cell{width:13px;height:13px;border-radius:2px;cursor:pointer;transition:transform .1s}
.hm-cell:hover{transform:scale(1.6);z-index:10;position:relative}
.hm-row-lbl{font-family:var(--mono);font-size:9px;color:var(--text-dim);text-align:right;padding-right:6px}
.hm-week-lbl{font-family:var(--mono);font-size:8px;color:var(--text-dim);text-align:center}

/* Legend */
.legend{display:flex;gap:12px;flex-wrap:wrap;padding:9px 18px;border-top:1px solid var(--border);background:var(--bg)}
.leg-item{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--text-mid);font-weight:500}
.leg-dot{width:8px;height:8px;border-radius:2px;flex-shrink:0}
.leg-line{width:16px;height:2px;flex-shrink:0}
.leg-hatch{width:14px;height:8px;border-radius:1px;flex-shrink:0;background:repeating-linear-gradient(45deg,#bbb,#bbb 2px,rgba(0,0,0,.1) 2px,rgba(0,0,0,.1) 4px)}

/* Day detail */
.day-detail{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--border)}
.detail-col{padding:14px 18px}
.detail-col+.detail-col{border-left:1px solid var(--border)}
.detail-title{font-size:9px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-dim);margin-bottom:10px}
.util-row{display:flex;align-items:center;gap:7px;margin-bottom:7px}
.util-lbl{font-size:11px;font-weight:500;width:76px;flex-shrink:0}
.util-track{flex:1;height:9px;background:var(--border);border-radius:5px;overflow:hidden}
.util-fill{height:100%;border-radius:5px;transition:width .4s}
.util-pct{font-family:var(--mono);font-size:10px;width:34px;text-align:right;font-weight:600}
.util-abs{font-family:var(--mono);font-size:9px;color:var(--text-dim);width:100px;text-align:right}
.sum-row{display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px solid var(--border)}
.sum-row:last-child{border-bottom:none}
.sum-key{font-size:12px;color:var(--text-mid)}
.sum-val{font-family:var(--mono);font-size:12px;font-weight:600}

/* Badges */
.badge{display:inline-flex;align-items:center;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:600}
.badge-ok{background:var(--ok-bg);color:var(--ok)}
.badge-warn{background:var(--warn-bg);color:var(--warn)}
.badge-amber{background:var(--amber-bg);color:var(--amber)}

/* Backlog chart */
.bl-wrap{padding:10px 18px}
.bl-bars{display:flex;align-items:flex-end;gap:1px;height:72px}
.bl-bar{flex:1;border-radius:1px 1px 0 0;cursor:pointer;min-height:0;transition:opacity .1s}

/* Monthly table */
.m-table-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
.m-table{width:100%;border-collapse:collapse}
.m-table th{font-size:9px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:var(--text-dim);text-align:left;padding:8px 13px;border-bottom:2px solid var(--border);background:var(--bg);white-space:nowrap}
.m-table td{padding:7px 13px;border-bottom:1px solid var(--border);font-size:12px}
.m-table tr:last-child td{border-bottom:none}
.m-table tbody tr:hover td{background:var(--blue-light)}
.wl-track{width:100%;height:5px;background:var(--border);border-radius:3px;overflow:hidden;min-width:70px}
.wl-fill{height:100%;border-radius:3px;transition:width .4s}

/* Tooltip */
.tooltip{position:fixed;background:#fff;border:1px solid var(--border);border-radius:var(--radius);padding:8px 11px;font-size:11px;pointer-events:none;z-index:9999;box-shadow:var(--shadow-lg);min-width:170px}
.tt-title{font-size:9px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--blue);margin-bottom:5px;border-bottom:1px solid var(--border);padding-bottom:4px}
.tt-row{display:flex;justify-content:space-between;gap:14px;margin-top:3px}
.tt-key{color:var(--text-dim)}
.tt-val{font-family:var(--mono);font-weight:600;color:var(--text)}
.tt-warn{color:var(--warn)}
.tt-ok{color:var(--ok)}

::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:var(--bg)}
::-webkit-scrollbar-thumb{background:var(--border-dark);border-radius:3px}

@media(max-width:1100px){
  .sidebar{width:48px}
  .sb-title,.sb-sub,.sb-item span,.sb-footer,.sb-section{display:none}
  .sb-item{justify-content:center;padding:10px 0;border-left:none;border-right:3px solid transparent}
  .sb-item.active{border-right-color:#fff;border-left:none}
  .kpi-strip{grid-template-columns:repeat(3,1fr)}
  .starts-grid,.dist-grid,.storage-grid,.day-detail{grid-template-columns:1fr}
  .detail-col+.detail-col{border-left:none;border-top:1px solid var(--border)}
}
`

export default css
