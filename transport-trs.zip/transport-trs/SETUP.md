# GitHub Setup Guide — Transport Registration System

Complete step-by-step instructions to get TRS running from scratch on GitHub
with CI/CD to a remote server.

---

## Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Git | any | https://git-scm.com |
| Docker Desktop | 24+ | https://docker.com/products/docker-desktop |
| Docker Compose | v2 (bundled with Docker Desktop) | — |
| Node.js | 20 LTS | https://nodejs.org (only needed for local frontend dev) |
| Python | 3.12 | https://python.org (only needed for local backend dev) |

---

## Part 1 — Local Development (no GitHub needed yet)

### Step 1 — Clone / initialise the project

If you received the zip file:
```bash
unzip transport-trs.zip
cd transport-trs
```

If starting from scratch (empty folder):
```bash
mkdir transport-trs && cd transport-trs
git init
# copy all project files in
```

### Step 2 — Create your `.env` file

```bash
cp .env.example .env
```

Open `.env` and at minimum change `SECRET_KEY` to a random string:
```bash
# Generate a secure key (run this, copy the output into .env)
python -c "import secrets; print(secrets.token_hex(32))"
```

Leave `DATABASE_URL` as-is for local Docker use.

### Step 3 — Start all services with Docker Compose

```bash
docker compose up -d
```

This will:
- Pull PostgreSQL 16
- Build the Python backend image
- Build the Node.js frontend image
- Start all three containers

First run takes 2–3 minutes. Check status:
```bash
docker compose ps
docker compose logs -f backend   # watch backend logs
```

### Step 4 — Verify it works

| URL | What you see |
|-----|-------------|
| http://localhost:5173 | TRS frontend (login page) |
| http://localhost:8000/docs | FastAPI Swagger UI |
| http://localhost:8000/health | `{"status":"ok"}` |

Login credentials (auto-created on first start):
- **Username:** `admin`
- **Password:** `changeme123`

> ⚠️ Change the password immediately via Admin → Users after first login.

### Step 5 — Stop the services

```bash
docker compose down          # stop but keep DB data
docker compose down -v       # stop AND wipe DB (fresh start)
```

---

## Part 2 — Push to GitHub

### Step 6 — Create a GitHub repository

1. Go to https://github.com/new
2. Name it `transport-trs` (or anything you like)
3. Set visibility: **Private** (internal tool)
4. **Do NOT** initialise with README, .gitignore, or license (you already have them)
5. Click **Create repository**

### Step 7 — Push your code

Copy the two commands GitHub shows you (they include your repo URL):

```bash
cd transport-trs

git init                          # skip if already done
git add .
git commit -m "feat: initial TRS project"

git remote add origin https://github.com/YOUR_ORG/transport-trs.git
git branch -M main
git push -u origin main
```

### Step 8 — Generate a `package-lock.json`

The CI pipeline uses `npm ci` which requires a lockfile. Generate it once locally:

```bash
cd frontend
npm install          # generates package-lock.json
cd ..
git add frontend/package-lock.json
git commit -m "chore: add package-lock.json"
git push
```

---

## Part 3 — GitHub Container Registry (GHCR)

Docker images are pushed to GitHub's free container registry. No setup needed —
the GitHub Actions workflow uses `GITHUB_TOKEN` automatically.

After a successful push to `main`, your images will appear at:
```
ghcr.io/YOUR_ORG/transport-trs/backend:latest
ghcr.io/YOUR_ORG/transport-trs/frontend:latest
```

---

## Part 4 — CI/CD Pipeline Setup

The workflow file is at `.github/workflows/ci.yml`. It runs automatically on every push.

### Step 9 — Add GitHub Secrets

Go to your repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

Add these secrets one by one:

| Secret name | Value | Where to find it |
|-------------|-------|-----------------|
| `DEPLOY_HOST` | IP or hostname of your server | Your server provider |
| `DEPLOY_USER` | SSH username (e.g. `ubuntu`, `deploy`) | Your server |
| `DEPLOY_SSH_KEY` | Private SSH key (full content of `~/.ssh/id_ed25519`) | See Step 10 |
| `DEPLOY_PATH` | Absolute path on server (e.g. `/opt/transport-trs`) | Your choice |

### Step 10 — Generate an SSH key for deployment

On your **local machine** (not the server):

```bash
ssh-keygen -t ed25519 -C "github-deploy-trs" -f ~/.ssh/trs_deploy
# Press Enter twice for no passphrase
```

This creates two files:
- `~/.ssh/trs_deploy` — **private key** → paste into `DEPLOY_SSH_KEY` secret
- `~/.ssh/trs_deploy.pub` — **public key** → add to server

**Add the public key to your server:**
```bash
ssh YOUR_USER@YOUR_SERVER
mkdir -p ~/.ssh
echo "PASTE_PUBLIC_KEY_CONTENT_HERE" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
```

**Copy the private key for the GitHub secret:**
```bash
cat ~/.ssh/trs_deploy
# Copy the ENTIRE output including -----BEGIN...----- and -----END...----- lines
```

### Step 11 — Create a GitHub Environment (optional but recommended)

GitHub Environments add a manual approval gate before deployment.

1. Go to repo → **Settings** → **Environments** → **New environment**
2. Name it `production`
3. Under **Deployment protection rules**, tick **Required reviewers** and add yourself
4. Click **Save protection rules**

If you skip this, deployments to `main` will run automatically.

---

## Part 5 — Server Setup

### Step 12 — Prepare the server

SSH into your server and run:

```bash
# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker

# Install Docker Compose plugin
sudo apt-get install -y docker-compose-plugin

# Create app directory
sudo mkdir -p /opt/transport-trs
sudo chown $USER:$USER /opt/transport-trs
cd /opt/transport-trs
```

### Step 13 — Create the production `.env` on the server

```bash
nano /opt/transport-trs/.env
```

Paste and fill in:
```env
DATABASE_URL=postgresql+asyncpg://trs:STRONG_PASSWORD@db:5432/transport_trs
DB_USER=trs
DB_PASSWORD=STRONG_PASSWORD
DB_NAME=transport_trs

SECRET_KEY=PASTE_YOUR_32_BYTE_HEX_KEY_HERE
ACCESS_TOKEN_EXPIRE_MINUTES=480
APP_ENV=production
BACKEND_CORS_ORIGINS=["http://YOUR_SERVER_IP"]

LABEL_WIDTH_MM=62
LABEL_HEIGHT_MM=29
LABEL_PRINTER_DPI=300
```

> Generate SECRET_KEY: `python3 -c "import secrets; print(secrets.token_hex(32))"`

### Step 14 — Copy docker-compose.prod.yml to the server

```bash
scp docker-compose.prod.yml YOUR_USER@YOUR_SERVER:/opt/transport-trs/
```

Or paste the contents manually via nano.

### Step 15 — First manual deployment

```bash
cd /opt/transport-trs

# Log into GHCR (use a GitHub Personal Access Token with read:packages)
echo YOUR_GITHUB_PAT | docker login ghcr.io -u YOUR_GITHUB_USERNAME --password-stdin

# Pull and start
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d
```

The app is now live on http://YOUR_SERVER_IP

---

## Part 6 — Verify the Full Pipeline

### Step 16 — Trigger a deployment

Make any small change, commit, and push:

```bash
git add .
git commit -m "test: trigger CI"
git push
```

Go to your repo → **Actions** tab to watch the pipeline run.

Stages:
1. ✅ **Backend Tests** (~1 min)
2. ✅ **Frontend Build** (~1 min)
3. ✅ **Build Docker Images** (~3 min, only on `main`)
4. ✅ **Deploy to Production** (~30 sec, only on `main`, requires approval if environment set up)

---

## Part 7 — Database Migrations (when schema changes)

The app auto-creates tables on startup in development. For production schema changes, use Alembic:

```bash
# Local: generate a migration after changing a model
cd backend
alembic revision --autogenerate -m "add new field"
alembic upgrade head

# On server (run inside the backend container):
docker compose -f docker-compose.prod.yml exec backend alembic upgrade head
```

---

## Troubleshooting

### Backend won't start
```bash
docker compose logs backend
# Common: DB not ready yet — wait 10 seconds and retry
# Common: wrong DATABASE_URL — check .env
```

### Frontend shows blank page
```bash
docker compose logs frontend
# Common: VITE_API_BASE_URL points to wrong backend URL
```

### Labels not printing
- PDF format: opens in browser → use browser print dialog (Ctrl+P / Cmd+P)
- ZPL format: send the `.zpl` file to your Zebra printer IP:
  ```bash
  cat label.zpl | nc YOUR_PRINTER_IP 9100
  ```

### CI fails with "npm ci" error
```bash
cd frontend && npm install && git add package-lock.json && git commit -m "fix: add lockfile" && git push
```

### "ghcr.io: unauthorized" on server
Generate a GitHub Personal Access Token at https://github.com/settings/tokens
with `read:packages` scope, then:
```bash
echo YOUR_PAT | docker login ghcr.io -u YOUR_USERNAME --password-stdin
```

---

## Quick Reference

| Task | Command |
|------|---------|
| Start local dev | `docker compose up -d` |
| Stop local dev | `docker compose down` |
| View backend logs | `docker compose logs -f backend` |
| Run backend tests | `cd backend && pytest tests/ -v` |
| Build frontend only | `cd frontend && npm run build` |
| Generate DB migration | `cd backend && alembic revision --autogenerate -m "description"` |
| Apply migrations | `cd backend && alembic upgrade head` |
| Reset local DB | `docker compose down -v && docker compose up -d` |
| SSH to server | `ssh YOUR_USER@YOUR_SERVER` |
| Prod deploy (manual) | `docker compose -f docker-compose.prod.yml pull && docker compose -f docker-compose.prod.yml up -d` |
