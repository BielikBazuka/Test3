import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  { path: '/login', component: () => import('@/views/LoginView.vue'), meta: { public: true } },
  {
    path: '/',
    component: () => import('@/views/AppShell.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: '', redirect: '/registrations' },
      { path: 'registrations', component: () => import('@/views/RegistrationsView.vue') },
      { path: 'registrations/new', component: () => import('@/views/RegistrationFormView.vue') },
      { path: 'registrations/:id/edit', component: () => import('@/views/RegistrationFormView.vue') },
      { path: 'admin/fields', component: () => import('@/views/admin/FieldsView.vue'), meta: { adminOnly: true } },
      { path: 'admin/users', component: () => import('@/views/admin/UsersView.vue'), meta: { adminOnly: true } },
    ],
  },
  { path: '/:pathMatch(.*)*', redirect: '/' },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach(async (to) => {
  const auth = useAuthStore()

  if (to.meta.public) return true

  if (!auth.isLoggedIn) return '/login'

  if (!auth.user) await auth.fetchMe()

  if (to.meta.adminOnly && !auth.isAdmin) return '/registrations'

  return true
})

export default router
