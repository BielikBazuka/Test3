import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '@/utils/api'

export const useRegistrationsStore = defineStore('registrations', () => {
  const items = ref([])
  const total = ref(0)
  const loading = ref(false)

  async function fetchAll(params = {}) {
    loading.value = true
    try {
      const res = await api.get('/registrations', { params })
      items.value = res.data
      total.value = res.data.length
    } finally {
      loading.value = false
    }
  }

  async function create(data) {
    const res = await api.post('/registrations', data)
    items.value.unshift(res.data)
    return res.data
  }

  async function update(id, data) {
    const res = await api.put(`/registrations/${id}`, data)
    const idx = items.value.findIndex((r) => r.id === id)
    if (idx !== -1) items.value[idx] = res.data
    return res.data
  }

  async function remove(id) {
    await api.delete(`/registrations/${id}`)
    items.value = items.value.filter((r) => r.id !== id)
  }

  async function exportExcel() {
    const res = await api.get('/registrations/export/excel', { responseType: 'blob' })
    downloadBlob(res.data, 'registrations.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  }

  async function exportCsv() {
    const res = await api.get('/registrations/export/csv', { responseType: 'blob' })
    downloadBlob(res.data, 'registrations.csv', 'text/csv')
  }

  function downloadBlob(data, filename, type) {
    const url = URL.createObjectURL(new Blob([data], { type }))
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)
  }

  return { items, total, loading, fetchAll, create, update, remove, exportExcel, exportCsv }
})
