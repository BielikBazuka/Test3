<template>
  <div>
    <div class="main-header">
      <RouterLink to="/registrations" class="btn btn-ghost btn-sm">← Back</RouterLink>
      <h1>{{ isEdit ? 'Edit Registration' : 'New Registration' }}</h1>
      <span v-if="isEdit && reg" class="trs-chip" style="margin-left:8px">{{ reg.trs_number }}</span>
    </div>

    <div class="main-content">
      <div v-if="loading" style="text-align:center;padding:48px;color:var(--text-muted)">Loading…</div>

      <form v-else @submit.prevent="handleSubmit">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;max-width:900px">

          <!-- Left column -->
          <div style="display:flex;flex-direction:column;gap:16px">
            <div class="card">
              <div class="card-header"><h3>📅 Arrival</h3></div>
              <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
                <div class="form-group">
                  <label class="form-label">Arrival Date & Time <span class="required">*</span></label>
                  <input v-model="form.arrival_timestamp" class="form-control" type="datetime-local" required />
                </div>
              </div>
            </div>

            <div class="card">
              <div class="card-header"><h3>🚚 Transport</h3></div>
              <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
                <div class="form-group">
                  <label class="form-label">Ship From <span class="required">*</span></label>
                  <input v-model="form.ship_from" class="form-control" placeholder="Supplier / Origin" required />
                </div>
                <div class="form-group">
                  <label class="form-label">Ship To <span class="required">*</span></label>
                  <input v-model="form.ship_to" class="form-control" placeholder="Destination warehouse" required />
                </div>
                <div class="form-group">
                  <label class="form-label">Truck Number</label>
                  <input v-model="form.truck_number" class="form-control mono" placeholder="AB-123-CD" />
                </div>
                <div class="form-group">
                  <label class="form-label">Driver Name</label>
                  <input v-model="form.driver_name" class="form-control" placeholder="Full name" />
                </div>
              </div>
            </div>
          </div>

          <!-- Right column -->
          <div style="display:flex;flex-direction:column;gap:16px">
            <div class="card">
              <div class="card-header"><h3>📦 Cargo</h3></div>
              <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                  <div class="form-group">
                    <label class="form-label">Collies</label>
                    <input v-model.number="form.num_collies" class="form-control" type="number" min="0" placeholder="0" />
                  </div>
                  <div class="form-group">
                    <label class="form-label">Pallets</label>
                    <input v-model.number="form.num_pallets" class="form-control" type="number" min="0" placeholder="0" />
                  </div>
                </div>
                <div class="form-group">
                  <label class="form-label">Notes</label>
                  <textarea v-model="form.notes" class="form-control" placeholder="Any additional notes…" rows="3" />
                </div>
              </div>
            </div>

            <!-- Dynamic custom fields -->
            <div v-if="customFields.length" class="card">
              <div class="card-header"><h3>🔧 Additional Fields</h3></div>
              <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
                <div v-for="field in customFields" :key="field.id" class="form-group">
                  <label class="form-label">
                    {{ field.label }}
                    <span v-if="field.required" class="required">*</span>
                  </label>

                  <select v-if="field.field_type === 'select'" v-model="form.custom_data[field.name]" class="form-control" :required="field.required">
                    <option value="">— Select —</option>
                    <option v-for="opt in field.options" :key="opt" :value="opt">{{ opt }}</option>
                  </select>

                  <input
                    v-else-if="field.field_type === 'date'"
                    v-model="form.custom_data[field.name]"
                    class="form-control"
                    type="date"
                    :required="field.required"
                  />

                  <input
                    v-else-if="field.field_type === 'number'"
                    v-model.number="form.custom_data[field.name]"
                    class="form-control"
                    type="number"
                    :required="field.required"
                  />

                  <label v-else-if="field.field_type === 'boolean'" class="flex items-center gap-2" style="cursor:pointer">
                    <input v-model="form.custom_data[field.name]" type="checkbox" />
                    {{ field.label }}
                  </label>

                  <input
                    v-else
                    v-model="form.custom_data[field.name]"
                    class="form-control"
                    type="text"
                    :required="field.required"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div v-if="fieldsError" class="alert alert-error" style="max-width:900px;margin-bottom:8px">{{ fieldsError }}</div>
        <div v-if="error" class="alert alert-error mt-4" style="max-width:900px">{{ error }}</div>

        <div class="flex gap-3 mt-4">
          <button type="submit" class="btn btn-primary" :disabled="saving">
            {{ saving ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Registration' }}
          </button>
          <RouterLink to="/registrations" class="btn btn-secondary">Cancel</RouterLink>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { useRegistrationsStore } from '@/stores/registrations'
import api from '@/utils/api'
import { format } from 'date-fns'

const route = useRoute()
const router = useRouter()
const store = useRegistrationsStore()

const isEdit = computed(() => !!route.params.id)
const loading = ref(true)   // always true on mount; cleared after both loads
const saving = ref(false)
const error = ref('')
const fieldsError = ref('')
const reg = ref(null)
const customFields = ref([])

const form = ref({
  arrival_timestamp: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
  ship_from: '',
  ship_to: '',
  truck_number: '',
  driver_name: '',
  num_collies: null,
  num_pallets: null,
  notes: '',
  custom_data: {},
})

onMounted(async () => {
  // Load custom fields
  try {
    const res = await api.get('/fields')
    customFields.value = res.data
    // Initialize custom_data keys
    for (const f of res.data) {
      if (!(f.name in form.value.custom_data)) {
        form.value.custom_data[f.name] = ''
      }
    }
  } catch {
    fieldsError.value = 'Could not load custom fields.'
  }

  // Load existing registration for edit
  if (isEdit.value) {
    try {
      const res = await api.get(`/registrations/${route.params.id}`)
      reg.value = res.data
      const r = res.data
      form.value = {
        arrival_timestamp: format(new Date(r.arrival_timestamp), "yyyy-MM-dd'T'HH:mm"),
        ship_from: r.ship_from,
        ship_to: r.ship_to,
        truck_number: r.truck_number || '',
        driver_name: r.driver_name || '',
        num_collies: r.num_collies,
        num_pallets: r.num_pallets,
        notes: r.notes || '',
        custom_data: r.custom_data || {},
      }
    } catch {
      error.value = 'Failed to load registration.'
    }
  }

  loading.value = false
})

async function handleSubmit() {
  error.value = ''
  saving.value = true
  try {
    const payload = {
      ...form.value,
      arrival_timestamp: new Date(form.value.arrival_timestamp).toISOString(),
    }
    if (isEdit.value) {
      await store.update(Number(route.params.id), payload)
    } else {
      await store.create(payload)
    }
    router.push('/registrations')
  } catch (e) {
    error.value = e.response?.data?.detail || 'Save failed.'
  } finally {
    saving.value = false
  }
}
</script>
