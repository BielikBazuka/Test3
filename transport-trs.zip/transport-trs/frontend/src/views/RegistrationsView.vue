<template>
  <div>
    <!-- Header -->
    <div class="main-header">
      <h1>Registrations</h1>
      <div class="flex gap-2" style="margin-left:auto">
        <input
          v-model="search"
          class="form-control"
          style="width:220px"
          placeholder="🔍 Search TRS, truck, driver…"
          @input="debouncedFetch"
        />
        <button class="btn btn-secondary btn-sm" @click="store.exportCsv()">⬇ CSV</button>
        <button class="btn btn-secondary btn-sm" @click="store.exportExcel()">⬇ Excel</button>
        <RouterLink to="/registrations/new" class="btn btn-primary btn-sm">+ New</RouterLink>
      </div>
    </div>

    <div class="main-content">
      <!-- Stats bar -->
      <div class="stats-bar mb-4">
        <div class="stat-item">
          <span class="stat-value">{{ store.total }}</span>
          <span class="stat-label">Total records</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ todayCount }}</span>
          <span class="stat-label">Today</span>
        </div>
      </div>

      <!-- Table -->
      <div class="card">
        <div v-if="store.loading" class="card-body" style="text-align:center;color:var(--text-muted)">
          Loading…
        </div>
        <div v-else-if="!store.items.length" class="card-body" style="text-align:center;color:var(--text-muted);padding:48px">
          No registrations yet. <RouterLink to="/registrations/new">Create the first one.</RouterLink>
        </div>
        <table v-else class="trs-table">
          <thead>
            <tr>
              <th>TRS Number</th>
              <th>Arrival</th>
              <th>Ship From</th>
              <th>Ship To</th>
              <th>Truck</th>
              <th>Driver</th>
              <th>Collies</th>
              <th>Pallets</th>
              <th style="text-align:right">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="reg in store.items" :key="reg.id">
              <td><span class="trs-chip">{{ reg.trs_number }}</span></td>
              <td class="mono" style="font-size:12px">{{ formatDate(reg.arrival_timestamp) }}</td>
              <td>{{ reg.ship_from }}</td>
              <td>{{ reg.ship_to }}</td>
              <td class="mono">{{ reg.truck_number || '—' }}</td>
              <td>{{ reg.driver_name || '—' }}</td>
              <td style="text-align:center">{{ reg.num_collies ?? '—' }}</td>
              <td style="text-align:center">{{ reg.num_pallets ?? '—' }}</td>
              <td style="text-align:right;white-space:nowrap">
                <button class="btn btn-ghost btn-sm" title="Print labels" @click="openLabelModal(reg)">🏷</button>
                <RouterLink :to="`/registrations/${reg.id}/edit`" class="btn btn-ghost btn-sm">✏️</RouterLink>
                <button
                  v-if="auth.isAdmin"
                  class="btn btn-ghost btn-sm"
                  style="color:var(--asml-danger)"
                  @click="confirmDelete(reg)"
                >🗑</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Label modal -->
    <div v-if="labelModal.open" class="modal-backdrop" @click.self="labelModal.open = false">
      <div class="modal">
        <div class="modal-header">
          <h3>🏷 Print Labels — {{ labelModal.reg?.trs_number }}</h3>
          <button class="btn btn-ghost btn-sm" @click="labelModal.open = false">✕</button>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:16px">
          <div class="form-group">
            <label class="form-label">Number of Labels</label>
            <input v-model.number="labelModal.count" class="form-control" type="number" min="1" max="50" />
          </div>
          <div class="form-group">
            <label class="form-label">Format</label>
            <select v-model="labelModal.format" class="form-control">
              <option value="pdf">PDF (any printer)</option>
              <option value="zpl">ZPL (Zebra printer)</option>
            </select>
          </div>
          <div class="alert alert-success" style="font-size:12px">
            Label size: 62mm × 29mm · Separate barcodes for date and time · ASML layout
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="labelModal.open = false">Cancel</button>
          <button class="btn btn-primary" :disabled="labelModal.loading" @click="printLabels">
            {{ labelModal.loading ? 'Generating…' : `Generate ${labelModal.count} Label(s)` }}
          </button>
        </div>
      </div>
    </div>

    <!-- Delete confirm modal -->
    <div v-if="deleteTarget" class="modal-backdrop" @click.self="deleteTarget = null">
      <div class="modal" style="max-width:400px">
        <div class="modal-header">
          <h3>Confirm Delete</h3>
        </div>
        <div class="modal-body">
          <p>Delete <strong>{{ deleteTarget.trs_number }}</strong>? This cannot be undone.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="deleteTarget = null">Cancel</button>
          <button class="btn btn-danger" @click="doDelete">Delete</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { useRegistrationsStore } from '@/stores/registrations'
import { useAuthStore } from '@/stores/auth'
import api from '@/utils/api'
import { format, isToday } from 'date-fns'

const store = useRegistrationsStore()
const auth = useAuthStore()
const search = ref('')
let debounceTimer = null

const todayCount = computed(() =>
  store.items.filter((r) => isToday(new Date(r.arrival_timestamp))).length
)

function formatDate(dt) {
  return dt ? format(new Date(dt), 'dd MMM yyyy HH:mm') : '—'
}

function debouncedFetch() {
  clearTimeout(debounceTimer)
  debounceTimer = setTimeout(() => store.fetchAll({ search: search.value }), 300)
}

onMounted(() => store.fetchAll())

// ── Label modal ──────────────────────────────────────────────────────────────
const labelModal = ref({ open: false, reg: null, count: 1, format: 'pdf', loading: false })

function openLabelModal(reg) {
  labelModal.value = { open: true, reg, count: 1, format: 'pdf', loading: false }
}

async function printLabels() {
  labelModal.value.loading = true
  try {
    const res = await api.post(
      '/labels/generate',
      {
        registration_id: labelModal.value.reg.id,
        num_labels: labelModal.value.count,
        format: labelModal.value.format,
      },
      { responseType: 'blob' }
    )
    const ext = labelModal.value.format === 'zpl' ? 'zpl' : 'pdf'
    const mime = ext === 'pdf' ? 'application/pdf' : 'text/plain'
    const url = URL.createObjectURL(new Blob([res.data], { type: mime }))
    const a = document.createElement('a')
    a.href = url
    a.download = `${labelModal.value.reg.trs_number}_labels.${ext}`
    if (ext === 'pdf') {
      window.open(url, '_blank') // open PDF in new tab for direct printing
    } else {
      a.click()
    }
    URL.revokeObjectURL(url)
    labelModal.value.open = false
  } catch (e) {
    alert('Label generation failed: ' + (e.response?.data?.detail || e.message))
  } finally {
    labelModal.value.loading = false
  }
}

// ── Delete ───────────────────────────────────────────────────────────────────
const deleteTarget = ref(null)

function confirmDelete(reg) {
  deleteTarget.value = reg
}

async function doDelete() {
  await store.remove(deleteTarget.value.id)
  deleteTarget.value = null
}
</script>

<style scoped>
.stats-bar {
  display: flex; gap: 24px;
}
.stat-item {
  background: white; border: 1px solid var(--border); border-radius: var(--radius-lg);
  padding: 12px 20px; display: flex; flex-direction: column; align-items: center;
  min-width: 100px;
}
.stat-value { font-size: 28px; font-weight: 700; color: var(--asml-blue); line-height: 1; }
.stat-label { font-size: 11px; color: var(--text-muted); margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
</style>
