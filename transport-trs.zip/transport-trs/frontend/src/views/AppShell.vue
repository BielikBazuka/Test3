<template>
  <div class="app-shell">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-logo">
        <div class="logo-text">ASML</div>
        <div class="logo-sub">Transport Registry</div>
      </div>

      <nav class="sidebar-nav">
        <div class="nav-section-label">Registry</div>
        <RouterLink class="nav-item" :class="{ active: isActive('/registrations') }" to="/registrations">
          <span class="nav-icon">📋</span> All Registrations
        </RouterLink>
        <RouterLink class="nav-item" to="/registrations/new">
          <span class="nav-icon">➕</span> New Registration
        </RouterLink>

        <template v-if="auth.isAdmin">
          <div class="nav-section-label" style="margin-top:16px">Admin</div>
          <RouterLink class="nav-item" :class="{ active: isActive('/admin/fields') }" to="/admin/fields">
            <span class="nav-icon">🔧</span> Manage Fields
          </RouterLink>
          <RouterLink class="nav-item" :class="{ active: isActive('/admin/users') }" to="/admin/users">
            <span class="nav-icon">👥</span> Users
          </RouterLink>
        </template>
      </nav>

      <div class="sidebar-user">
        <div class="user-name">{{ auth.user?.full_name || auth.user?.username }}</div>
        <div class="user-role">{{ auth.user?.role === 'admin' ? '⭐ Admin' : 'User' }}</div>
        <button class="btn btn-ghost btn-sm" style="color:rgba(255,255,255,0.5);margin-top:8px;padding:4px 0" @click="handleLogout">
          Sign out
        </button>
      </div>
    </aside>

    <!-- Main area -->
    <div class="main-area">
      <RouterView />
    </div>
  </div>
</template>

<script setup>
import { RouterLink, RouterView, useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()

function isActive(path) {
  return route.path.startsWith(path)
}

function handleLogout() {
  auth.logout()
  router.push('/login')
}
</script>
