<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-header">
        <div class="login-logo">ASML</div>
        <h1>Transport Registration System</h1>
        <p class="text-muted">Sign in to continue</p>
      </div>

      <form class="login-form" @submit.prevent="handleLogin">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input
            v-model="username"
            class="form-control"
            type="text"
            placeholder="Enter username"
            autocomplete="username"
            required
          />
        </div>

        <div class="form-group">
          <label class="form-label">Password</label>
          <input
            v-model="password"
            class="form-control"
            type="password"
            placeholder="Enter password"
            autocomplete="current-password"
            required
          />
        </div>

        <div v-if="error" class="alert alert-error">{{ error }}</div>

        <button class="btn btn-primary btn-lg" type="submit" :disabled="loading" style="width:100%">
          {{ loading ? 'Signing in…' : 'Sign In' }}
        </button>
      </form>

      <div class="login-footer">
        <span class="text-muted text-small">TRS v1.0 · ASML Internal</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const router = useRouter()
const username = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')

async function handleLogin() {
  error.value = ''
  loading.value = true
  try {
    await auth.login(username.value, password.value)
    router.push('/registrations')
  } catch (e) {
    error.value = e.response?.data?.detail || 'Login failed. Please try again.'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  background: var(--asml-blue);
  background-image:
    repeating-linear-gradient(0deg, transparent, transparent 39px, rgba(255,255,255,0.04) 40px),
    repeating-linear-gradient(90deg, transparent, transparent 39px, rgba(255,255,255,0.04) 40px);
  display: flex; align-items: center; justify-content: center; padding: 20px;
}
.login-card {
  background: white; border-radius: 8px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  width: 100%; max-width: 380px;
  overflow: hidden;
}
.login-header {
  background: var(--asml-blue);
  padding: 32px 32px 28px;
  text-align: center;
}
.login-logo {
  font-size: 28px; font-weight: 800; color: white;
  letter-spacing: 4px; margin-bottom: 12px;
}
.login-header h1 { color: white; font-size: 16px; font-weight: 500; margin-bottom: 4px; }
.login-header p { color: rgba(255,255,255,0.6); font-size: 13px; }
.login-form { padding: 28px 32px; display: flex; flex-direction: column; gap: 16px; }
.login-footer { padding: 14px 32px; border-top: 1px solid var(--border); text-align: center; }
</style>
