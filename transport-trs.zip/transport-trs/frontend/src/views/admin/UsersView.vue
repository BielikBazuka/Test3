<template>
  <div>
    <div class="main-header">
      <h1>👥 Users</h1>
      <button class="btn btn-primary btn-sm" style="margin-left:auto" @click="openCreate">+ Add User</button>
    </div>

    <div class="main-content">
      <div class="card">
        <table class="trs-table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Full Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td class="mono" style="font-weight:600">{{ u.username }}</td>
              <td>{{ u.full_name || '—' }}</td>
              <td>{{ u.email || '—' }}</td>
              <td>
                <span class="badge" :class="u.role === 'admin' ? 'badge-blue' : 'badge-green'">
                  {{ u.role }}
                </span>
              </td>
              <td>{{ u.is_active ? '✅ Active' : '⛔ Inactive' }}</td>
              <td class="mono text-small">{{ u.created_at?.slice(0, 10) }}</td>
              <td>
                <button class="btn btn-ghost btn-sm" @click="openEdit(u)">✏️</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal -->
    <div v-if="modal.open" class="modal-backdrop" @click.self="modal.open = false">
      <div class="modal">
        <div class="modal-header">
          <h3>{{ modal.editing ? 'Edit User' : 'New User' }}</h3>
          <button class="btn btn-ghost btn-sm" @click="modal.open = false">✕</button>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <div class="form-group">
            <label class="form-label">Username <span class="required">*</span></label>
            <input v-model="modal.form.username" class="form-control mono" :disabled="modal.editing" />
          </div>
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input v-model="modal.form.full_name" class="form-control" />
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input v-model="modal.form.email" class="form-control" type="email" />
          </div>
          <div class="form-group">
            <label class="form-label">Role</label>
            <select v-model="modal.form.role" class="form-control">
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">{{ modal.editing ? 'New Password (leave blank to keep)' : 'Password *' }}</label>
            <input v-model="modal.form.password" class="form-control" type="password" :required="!modal.editing" />
          </div>
          <label v-if="modal.editing" class="flex items-center gap-2" style="cursor:pointer">
            <input v-model="modal.form.is_active" type="checkbox" />
            Active
          </label>
          <div v-if="modal.error" class="alert alert-error">{{ modal.error }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="modal.open = false">Cancel</button>
          <button class="btn btn-primary" :disabled="modal.saving" @click="saveUser">
            {{ modal.saving ? 'Saving…' : 'Save' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/utils/api'

const users = ref([])
const defaultForm = () => ({ username: '', full_name: '', email: '', role: 'user', password: '', is_active: true })
const modal = ref({ open: false, editing: false, form: defaultForm(), saving: false, error: '' })

async function loadUsers() {
  const res = await api.get('/auth/users')
  users.value = res.data
}
onMounted(loadUsers)

function openCreate() {
  modal.value = { open: true, editing: false, form: defaultForm(), saving: false, error: '' }
}
function openEdit(u) {
  modal.value = { open: true, editing: true, form: { ...u, password: '' }, saving: false, error: '' }
}

async function saveUser() {
  modal.value.error = ''
  modal.value.saving = true
  try {
    const { form } = modal.value
    const payload = { ...form }
    if (!payload.password) delete payload.password
    if (modal.value.editing) {
      await api.put(`/auth/users/${form.id}`, payload)
    } else {
      await api.post('/auth/users', payload)
    }
    modal.value.open = false
    await loadUsers()
  } catch (e) {
    modal.value.error = e.response?.data?.detail || 'Save failed.'
  } finally {
    modal.value.saving = false
  }
}
</script>
