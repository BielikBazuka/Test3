<template>
  <div>
    <div class="main-header">
      <h1>🔧 Manage Fields</h1>
      <button class="btn btn-primary btn-sm" style="margin-left:auto" @click="openCreate">+ Add Field</button>
    </div>

    <div class="main-content">
      <div class="card">
        <div class="card-header">
          <h3>Custom Fields</h3>
          <span class="text-muted text-small">Fields are rendered on the registration form for all users</span>
        </div>

        <div v-if="!fields.length" class="card-body" style="text-align:center;color:var(--text-muted);padding:32px">
          No custom fields yet.
        </div>

        <table v-else class="trs-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Name (key)</th>
              <th>Label</th>
              <th>Type</th>
              <th>Required</th>
              <th>Active</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="field in fields" :key="field.id">
              <td class="mono text-muted" style="font-size:11px">{{ field.order }}</td>
              <td><code style="background:var(--surface-2);padding:2px 6px;border-radius:3px;font-size:12px">{{ field.name }}</code></td>
              <td>{{ field.label }}</td>
              <td><span class="badge badge-blue">{{ field.field_type }}</span></td>
              <td>{{ field.required ? '✅' : '—' }}</td>
              <td>{{ field.is_active ? '✅' : '⛔' }}</td>
              <td>
                <button class="btn btn-ghost btn-sm" @click="openEdit(field)">✏️</button>
                <button class="btn btn-ghost btn-sm" style="color:var(--asml-danger)" @click="confirmDelete(field)">🗑</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Create/Edit Modal -->
    <div v-if="modal.open" class="modal-backdrop" @click.self="modal.open = false">
      <div class="modal">
        <div class="modal-header">
          <h3>{{ modal.editing ? 'Edit Field' : 'Add Custom Field' }}</h3>
          <button class="btn btn-ghost btn-sm" @click="modal.open = false">✕</button>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;gap:14px">
          <div class="form-group">
            <label class="form-label">Field Key (snake_case) <span class="required">*</span></label>
            <input v-model="modal.form.name" class="form-control mono" placeholder="e.g. po_number" :disabled="modal.editing" />
          </div>
          <div class="form-group">
            <label class="form-label">Display Label <span class="required">*</span></label>
            <input v-model="modal.form.label" class="form-control" placeholder="e.g. PO Number" />
          </div>
          <div class="form-group">
            <label class="form-label">Field Type</label>
            <select v-model="modal.form.field_type" class="form-control">
              <option value="text">Text</option>
              <option value="number">Number</option>
              <option value="date">Date</option>
              <option value="select">Select (dropdown)</option>
              <option value="boolean">Checkbox</option>
            </select>
          </div>
          <div v-if="modal.form.field_type === 'select'" class="form-group">
            <label class="form-label">Options (one per line)</label>
            <textarea
              class="form-control mono"
              rows="4"
              placeholder="Option 1&#10;Option 2&#10;Option 3"
              :value="(modal.form.options || []).join('\n')"
              @input="modal.form.options = $event.target.value.split('\n').filter(Boolean)"
            />
          </div>
          <div class="flex gap-4">
            <div class="form-group">
              <label class="form-label">Order</label>
              <input v-model.number="modal.form.order" class="form-control" type="number" min="0" style="width:80px" />
            </div>
            <label class="flex items-center gap-2" style="cursor:pointer;margin-top:22px">
              <input v-model="modal.form.required" type="checkbox" />
              Required
            </label>
            <label class="flex items-center gap-2" style="cursor:pointer;margin-top:22px">
              <input v-model="modal.form.is_active" type="checkbox" />
              Active
            </label>
          </div>
          <div v-if="modal.error" class="alert alert-error">{{ modal.error }}</div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="modal.open = false">Cancel</button>
          <button class="btn btn-primary" :disabled="modal.saving" @click="saveField">
            {{ modal.saving ? 'Saving…' : 'Save' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Delete confirm -->
    <div v-if="deleteTarget" class="modal-backdrop" @click.self="deleteTarget = null">
      <div class="modal" style="max-width:380px">
        <div class="modal-header"><h3>Delete Field</h3></div>
        <div class="modal-body">
          <p>Delete field <strong>{{ deleteTarget.label }}</strong> (<code>{{ deleteTarget.name }}</code>)?</p>
          <p class="text-muted text-small mt-2">Existing data stored under this key will remain in the database but won't display.</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" @click="deleteTarget = null">Cancel</button>
          <button class="btn btn-danger" @click="doDelete">Delete</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '@/utils/api'

const fields = ref([])
const deleteTarget = ref(null)

const defaultForm = () => ({
  name: '', label: '', field_type: 'text', options: [],
  required: false, order: 0, is_active: true,
})

const modal = ref({ open: false, editing: false, form: defaultForm(), saving: false, error: '' })

async function loadFields() {
  const res = await api.get('/fields/all')
  fields.value = res.data
}

onMounted(loadFields)

function openCreate() {
  modal.value = { open: true, editing: false, form: defaultForm(), saving: false, error: '' }
}

function openEdit(field) {
  modal.value = {
    open: true, editing: true,
    form: { ...field, options: field.options || [] },
    saving: false, error: '',
  }
}

async function saveField() {
  modal.value.error = ''
  modal.value.saving = true
  try {
    if (modal.value.editing) {
      await api.put(`/fields/${modal.value.form.id}`, modal.value.form)
    } else {
      await api.post('/fields', modal.value.form)
    }
    modal.value.open = false
    await loadFields()
  } catch (e) {
    modal.value.error = e.response?.data?.detail || 'Save failed.'
  } finally {
    modal.value.saving = false
  }
}

function confirmDelete(field) {
  deleteTarget.value = field
}

async function doDelete() {
  await api.delete(`/fields/${deleteTarget.value.id}`)
  deleteTarget.value = null
  await loadFields()
}
</script>
