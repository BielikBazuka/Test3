# 🚚 Transport Registration System (TRS)

A modern web-based transport registration system replacing DHL TRS, built for ASML logistics operations.

## Features

- 📦 **Transport Registration** — Register truck arrivals with full details (ship from/to, collies/pallets, truck number, driver)
- 🏷️ **Label Printing** — Generate ZPL/PDF labels with separate barcodes for date and time, formatted for small label stickers (ASML branding)
- 👤 **Role-Based Access** — Admin (full CRUD on fields + records) / Regular user (add + edit records)
- 📊 **Export** — Export registry to Excel or CSV
- 🔧 **Dynamic Fields** — Admins can add, edit, delete custom fields without touching code
- 🔍 **Barcode Support** — Code128 barcodes for date and time on every label

## Tech Stack

| Layer | Technology |
|-------|------------|
| Backend | FastAPI + SQLAlchemy + PostgreSQL |
| Frontend | Vue 3 + Pinia + Vite |
| Auth | JWT (+ SAML SSO ready) |
| Labels | ZPL generation + PDF fallback (reportlab) |
| Export | openpyxl + csv |
| Containerization | Docker + Docker Compose |

## Quick Start

### Prerequisites
- Docker & Docker Compose
- (Optional) Node.js 18+ for local frontend dev

### 1. Clone & Configure

```bash
git clone https://gitlab.asml.com/your-group/transport-trs.git
cd transport-trs
cp .env.example .env
# Edit .env with your values
```

### 2. Run with Docker Compose

```bash
docker compose up -d
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

### 3. First Login

Default admin credentials (change immediately):
- Username: `admin`
- Password: `changeme123`

## Development

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

## Label Format

Labels are designed for **62mm × 29mm** sticker rolls (compatible with Zebra ZD-series / Brother QL-series printers).

Each label contains:
- ASML logo header
- Registration number (large, bold)
- Barcode 1: **Date** (Code128, YYYYMMDD)
- Barcode 2: **Time** (Code128, HHMM)
- Ship From / Ship To
- Truck number + Driver
- Collies / Pallets count

## API Reference

Full OpenAPI docs available at `/docs` when running.

Key endpoints:
- `POST /api/v1/auth/login` — Get JWT token
- `GET/POST /api/v1/registrations` — List / create registrations
- `PUT/DELETE /api/v1/registrations/{id}` — Edit / delete
- `GET /api/v1/registrations/export/excel` — Excel export
- `GET /api/v1/registrations/export/csv` — CSV export
- `POST /api/v1/labels/generate` — Generate label(s)
- `GET/POST/PUT/DELETE /api/v1/fields` — Admin: manage custom fields

## Project Structure

```
transport-trs/
├── backend/
│   ├── app/
│   │   ├── api/          # Route handlers
│   │   ├── models/       # SQLAlchemy ORM models
│   │   ├── schemas/      # Pydantic schemas
│   │   ├── services/     # Business logic
│   │   └── core/         # Config, auth, db
│   ├── alembic/          # DB migrations
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/   # Vue components
│   │   ├── views/        # Page views
│   │   ├── stores/       # Pinia stores
│   │   └── utils/        # Helpers (label gen, export)
│   └── package.json
├── docker-compose.yml
└── .env.example
```

## License

Internal ASML use only.
