from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+asyncpg://trs:trs_password@db:5432/transport_trs"
    SECRET_KEY: str = "dev-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    APP_ENV: str = "development"
    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:8000"]

    LABEL_WIDTH_MM: int = 62
    LABEL_HEIGHT_MM: int = 29
    LABEL_PRINTER_DPI: int = 300

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
