from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import engine, Base, AsyncSessionLocal
from app.core.auth import hash_password
from app.models.user import User  # noqa: ensure model is imported
from app.models.registration import Registration, CustomField  # noqa
from app.api import auth, registrations, labels, fields
from sqlalchemy import select, func


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create tables on startup (dev mode — use Alembic migrations in prod)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed default admin if no users exist
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(func.count(User.id)))
        count = result.scalar()
        if count == 0:
            admin = User(
                username="admin",
                full_name="System Admin",
                role="admin",
                hashed_password=hash_password("changeme123"),
            )
            db.add(admin)
            await db.commit()
            print("✅ Default admin created: admin / changeme123")

    yield


app = FastAPI(
    title="Transport Registration System",
    description="TRS — ASML logistics transport registration",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/v1")
app.include_router(registrations.router, prefix="/api/v1")
app.include_router(labels.router, prefix="/api/v1")
app.include_router(fields.router, prefix="/api/v1")


@app.get("/health")
async def health():
    return {"status": "ok"}
