import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import List

from app.models.registration import Registration


ASML_BLUE = "001871"
LIGHT_BLUE = "E8EEFF"

COLUMNS = [
    ("TRS Number", "trs_number"),
    ("Arrival", "arrival_timestamp"),
    ("Ship From", "ship_from"),
    ("Ship To", "ship_to"),
    ("Truck Number", "truck_number"),
    ("Driver Name", "driver_name"),
    ("Collies", "num_collies"),
    ("Pallets", "num_pallets"),
    ("Notes", "notes"),
    ("Created At", "created_at"),
]


def generate_excel(registrations: List[Registration]) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Registrations"

    # Header row styling
    header_font = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill("solid", fgColor=ASML_BLUE)
    header_align = Alignment(horizontal="center", vertical="center")
    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    ws.row_dimensions[1].height = 22

    for col_idx, (header, _) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = border

    # Data rows
    alt_fill = PatternFill("solid", fgColor=LIGHT_BLUE)
    for row_idx, reg in enumerate(registrations, start=2):
        fill = alt_fill if row_idx % 2 == 0 else None
        for col_idx, (_, attr) in enumerate(COLUMNS, start=1):
            value = getattr(reg, attr, "")
            if hasattr(value, "strftime"):
                value = value.strftime("%Y-%m-%d %H:%M")
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.border = border
            cell.alignment = Alignment(vertical="center")
            if fill:
                cell.fill = fill

    # Auto-fit column widths
    for col_idx, (header, _) in enumerate(COLUMNS, start=1):
        max_len = len(header)
        for row_idx in range(2, ws.max_row + 1):
            val = ws.cell(row=row_idx, column=col_idx).value
            if val:
                max_len = max(max_len, len(str(val)))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 4, 40)

    # Freeze header
    ws.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
