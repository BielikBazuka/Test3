import csv
import io
from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text

from app.models.registration import Registration
from app.models.user import User
from app.schemas.registration import RegistrationCreate, RegistrationUpdate


async def generate_trs_number(db: AsyncSession, arrival_dt: datetime) -> str:
    """Generate a collision-safe TRS-YYYYMMDD-NNNN number.

    Uses a DB-level advisory lock (pg_try_advisory_xact_lock) so concurrent
    inserts cannot produce duplicate sequence numbers for the same day.
    The date is taken from the arrival timestamp (Amsterdam time, CET/CEST).
    """
    # Determine local date from arrival timestamp (Europe/Amsterdam UTC+1/+2)
    # We use the arrival date so the TRS number reflects the actual arrival day.
    import zoneinfo
    ams = zoneinfo.ZoneInfo("Europe/Amsterdam")
    local_dt = arrival_dt.astimezone(ams) if arrival_dt.tzinfo else arrival_dt
    today = local_dt.strftime("%Y%m%d")
    prefix = f"TRS-{today}-"

    # Acquire an advisory lock keyed on today's date integer to serialise
    # sequence generation without a dedicated sequence table.
    date_int = int(today)
    await db.execute(text(f"SELECT pg_advisory_xact_lock({date_int})"))

    result = await db.execute(
        select(func.count(Registration.id)).where(
            Registration.trs_number.like(f"{prefix}%")
        )
    )
    count = result.scalar() or 0
    return f"{prefix}{count + 1:04d}"


async def create_registration(
    db: AsyncSession,
    data: RegistrationCreate,
    user: User,
) -> Registration:
    trs_number = await generate_trs_number(db, data.arrival_timestamp)
    reg = Registration(
        trs_number=trs_number,
        created_by_id=user.id,
        **data.model_dump(),
    )
    db.add(reg)
    await db.commit()
    await db.refresh(reg)
    return reg


async def get_registration(db: AsyncSession, reg_id: int) -> Optional[Registration]:
    result = await db.execute(
        select(Registration).where(Registration.id == reg_id)
    )
    return result.scalar_one_or_none()


async def list_registrations(
    db: AsyncSession,
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
) -> List[Registration]:
    q = select(Registration).order_by(Registration.created_at.desc())
    if search:
        q = q.where(
            Registration.trs_number.ilike(f"%{search}%")
            | Registration.ship_from.ilike(f"%{search}%")
            | Registration.ship_to.ilike(f"%{search}%")
            | Registration.driver_name.ilike(f"%{search}%")
            | Registration.truck_number.ilike(f"%{search}%")
        )
    q = q.offset(skip).limit(limit)
    result = await db.execute(q)
    return result.scalars().all()


async def update_registration(
    db: AsyncSession,
    reg: Registration,
    data: RegistrationUpdate,
    user: User,
) -> Registration:
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(reg, key, value)
    reg.updated_by_id = user.id
    await db.commit()
    await db.refresh(reg)
    return reg


async def delete_registration(db: AsyncSession, reg: Registration) -> None:
    await db.delete(reg)
    await db.commit()


async def export_to_csv(db: AsyncSession) -> str:
    regs = await list_registrations(db, limit=100_000)
    output = io.StringIO()
    fields = [
        "trs_number", "arrival_timestamp", "ship_from", "ship_to",
        "truck_number", "driver_name", "num_collies", "num_pallets",
        "notes", "created_at",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for r in regs:
        row = {f: getattr(r, f, "") for f in fields}
        writer.writerow(row)
    return output.getvalue()
