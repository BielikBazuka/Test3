"""
Label generation for transport registrations.

Supports two output formats:
  - PDF: rendered via reportlab, ready to print on any printer
  - ZPL: Zebra Programming Language, sent directly to Zebra printers

Label layout (62mm × 29mm):
  ┌─────────────────────────────────────────┐
  │ ASML  [logo area]          TRS-20240101 │
  │─────────────────────────────────────────│
  │ ║▌▌▌║▌▌║  DATE BARCODE  ║▌▌▌║▌▌║      │
  │           20240101                      │
  │ ║▌▌▌║▌▌║  TIME BARCODE  ║▌▌▌║▌▌║      │
  │           1430                          │
  │─────────────────────────────────────────│
  │ FROM: Supplier XY    TO: ASML WH B      │
  │ TRUCK: AB-123-CD   DRIVER: J. Kowalski  │
  │ 📦 Collies: 12     🔲 Pallets: 2       │
  └─────────────────────────────────────────┘
"""

import io
from datetime import datetime
from typing import Literal

from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.graphics.barcode import code128
from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Drawing

from app.models.registration import Registration

# Label dimensions
W_MM = 62
H_MM = 29
PADDING = 1.5 * mm

ASML_BLUE = colors.HexColor("#001871")
ASML_LIGHT = colors.HexColor("#E8EEFF")
WHITE = colors.white
DARK = colors.HexColor("#1A1A1A")


def _barcode_drawing(value: str, width: float, height: float) -> Drawing:
    """Return a Code128 barcode as a Drawing object."""
    bc = code128.Code128(
        value,
        barWidth=0.6,
        barHeight=height,
        humanReadable=False,
        quiet=False,
    )
    d = Drawing(width, height)
    d.add(bc)
    return d


def generate_pdf_labels(reg: Registration, num_labels: int = 1) -> bytes:
    """Generate a PDF with num_labels copies of the registration label."""
    page_w = W_MM * mm
    page_h = H_MM * mm

    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=(page_w, page_h))

    arrival: datetime = reg.arrival_timestamp
    date_str = arrival.strftime("%Y%m%d")
    time_str = arrival.strftime("%H%M")
    date_display = arrival.strftime("%Y-%m-%d")
    time_display = arrival.strftime("%H:%M")

    for label_idx in range(num_labels):
        if label_idx > 0:
            c.showPage()

        # ── Background ──────────────────────────────────────────────────
        c.setFillColor(WHITE)
        c.rect(0, 0, page_w, page_h, fill=1, stroke=0)

        # ── Header bar ──────────────────────────────────────────────────
        header_h = 6.5 * mm
        c.setFillColor(ASML_BLUE)
        c.rect(0, page_h - header_h, page_w, header_h, fill=1, stroke=0)

        c.setFillColor(WHITE)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(PADDING, page_h - 4.8 * mm, "ASML")

        c.setFont("Helvetica", 6)
        c.drawRightString(page_w - PADDING, page_h - 4.8 * mm, reg.trs_number)

        # ── Barcode section ──────────────────────────────────────────────
        bc_h = 7 * mm
        bc_w = page_w * 0.55
        bc_x = PADDING
        top_area = page_h - header_h

        # Date barcode
        date_y = top_area - bc_h - 1.5 * mm
        d_date = _barcode_drawing(date_str, bc_w, bc_h)
        renderPDF.draw(d_date, c, bc_x, date_y)

        c.setFillColor(DARK)
        c.setFont("Helvetica", 5)
        c.drawString(bc_x, date_y - 3 * mm, f"DATE  {date_display}")

        # Time barcode
        time_y = date_y - bc_h - 4 * mm
        d_time = _barcode_drawing(time_str, bc_w, bc_h)
        renderPDF.draw(d_time, c, bc_x, time_y)
        c.drawString(bc_x, time_y - 3 * mm, f"TIME  {time_display}")

        # ── Right info panel ─────────────────────────────────────────────
        info_x = bc_w + PADDING * 2
        info_w = page_w - info_x - PADDING

        c.setFillColor(ASML_LIGHT)
        c.rect(info_x, time_y - 3.5 * mm, info_w, top_area - time_y + 3.5 * mm - 0.5 * mm, fill=1, stroke=0)

        c.setFillColor(DARK)
        c.setFont("Helvetica-Bold", 5)
        y_info = top_area - 3.5 * mm
        line_h = 3.5 * mm

        def draw_info(label: str, value: str, y: float):
            c.setFont("Helvetica-Bold", 4.5)
            c.setFillColor(ASML_BLUE)
            c.drawString(info_x + 1 * mm, y, label)
            c.setFont("Helvetica", 4.5)
            c.setFillColor(DARK)
            c.drawString(info_x + 1 * mm, y - 3 * mm, str(value or "—"))

        draw_info("TRUCK", reg.truck_number or "—", y_info)
        draw_info("DRIVER", reg.driver_name or "—", y_info - line_h * 1.8)

        # ── Footer strip ─────────────────────────────────────────────────
        footer_h = 5 * mm
        c.setFillColor(colors.HexColor("#F0F0F0"))
        c.rect(0, 0, page_w, footer_h, fill=1, stroke=0)

        c.setFillColor(DARK)
        c.setFont("Helvetica", 4.5)
        from_str = f"FROM: {(reg.ship_from or '—')[:22]}"
        to_str = f"TO: {(reg.ship_to or '—')[:22]}"
        c.drawString(PADDING, 3.2 * mm, from_str)
        c.drawString(PADDING, 0.8 * mm, to_str)

        collies_str = f"COL: {reg.num_collies or 0}"
        pallets_str = f"PAL: {reg.num_pallets or 0}"
        c.drawRightString(page_w - PADDING, 3.2 * mm, collies_str)
        c.drawRightString(page_w - PADDING, 0.8 * mm, pallets_str)

        # ── Border ───────────────────────────────────────────────────────
        c.setStrokeColor(ASML_BLUE)
        c.setLineWidth(0.5)
        c.rect(0, 0, page_w, page_h, fill=0, stroke=1)

    c.save()
    return buf.getvalue()


def generate_zpl_labels(reg: Registration, num_labels: int = 1) -> str:
    """Generate ZPL II string for Zebra printers (300 DPI, 62mm x 29mm)."""
    arrival: datetime = reg.arrival_timestamp
    date_str = arrival.strftime("%Y%m%d")
    time_str = arrival.strftime("%H%M")
    date_display = arrival.strftime("%Y-%m-%d")
    time_display = arrival.strftime("%H:%M")

    # 300 DPI: 1mm ≈ 11.8 dots
    D = 11.8

    def dots(mm_val: float) -> int:
        return int(mm_val * D)

    zpl_parts = []
    for _ in range(num_labels):
        zpl = f"""^XA
^PW{dots(W_MM)}
^LL{dots(H_MM)}
^CI28

^FO0,0^GB{dots(W_MM)},{dots(6)},0,^FS
^FO0,0^GB{dots(W_MM)},{dots(6)},{dots(6)},B^FS
^FO{dots(1)},{dots(1)}^A0N,{dots(4)},{dots(4)}^FDASML^FS
^FO{dots(30)},{dots(1)}^A0N,{dots(4)},{dots(4)}^FD{reg.trs_number}^FS

^FO{dots(1)},{dots(7)}^BY1.2,2,{dots(7)}^BCN,,N,N^FD{date_str}^FS
^FO{dots(1)},{dots(15)}^A0N,{dots(2.5)},{dots(2.5)}^FDDATE  {date_display}^FS

^FO{dots(1)},{dots(17.5)}^BY1.2,2,{dots(7)}^BCN,,N,N^FD{time_str}^FS
^FO{dots(1)},{dots(25.5)}^A0N,{dots(2.5)},{dots(2.5)}^FDTIME  {time_display}^FS

^FO{dots(35)},{dots(7)}^A0N,{dots(3)},{dots(3)}^FDTRUCK:^FS
^FO{dots(35)},{dots(10.5)}^A0N,{dots(3.5)},{dots(3.5)}^FD{(reg.truck_number or '—')[:12]}^FS
^FO{dots(35)},{dots(14.5)}^A0N,{dots(3)},{dots(3)}^FDDRIVER:^FS
^FO{dots(35)},{dots(18)}^A0N,{dots(3.5)},{dots(3.5)}^FD{(reg.driver_name or '—')[:12]}^FS

^FO0,{dots(24)}^GB{dots(W_MM)},{dots(0.4)},{dots(0.4)},B^FS
^FO{dots(1)},{dots(24.5)}^A0N,{dots(2.5)},{dots(2.5)}^FDFROM: {(reg.ship_from or '—')[:20]}^FS
^FO{dots(1)},{dots(26.8)}^A0N,{dots(2.5)},{dots(2.5)}^FDTO: {(reg.ship_to or '—')[:20]}^FS
^FO{dots(44)},{dots(24.5)}^A0N,{dots(2.5)},{dots(2.5)}^FD{reg.num_collies or 0} col^FS
^FO{dots(44)},{dots(26.8)}^A0N,{dots(2.5)},{dots(2.5)}^FD{reg.num_pallets or 0} pal^FS

^GB{dots(W_MM)},{dots(H_MM)},{dots(0.4)},B^FS
^XZ"""
        zpl_parts.append(zpl)

    return "\n".join(zpl_parts)
