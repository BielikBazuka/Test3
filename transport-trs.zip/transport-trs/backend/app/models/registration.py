from sqlalchemy import (
    Column, Integer, String, DateTime, JSON, Text, ForeignKey, Boolean
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.core.database import Base


class CustomField(Base):
    """Admin-managed extra fields that appear on the registration form."""
    __tablename__ = "custom_fields"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(64), unique=True, nullable=False)       # internal key
    label = Column(String(128), nullable=False)                   # display label
    field_type = Column(String(32), nullable=False, default="text")
    # field_type: text | number | select | date | boolean
    options = Column(JSON, nullable=True)                         # for select fields
    required = Column(Boolean, default=False)
    order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Registration(Base):
    """Core transport registration record."""
    __tablename__ = "registrations"

    id = Column(Integer, primary_key=True, index=True)

    # Auto-generated TRS number
    trs_number = Column(String(32), unique=True, nullable=False, index=True)

    # Core fields (always present)
    arrival_timestamp = Column(DateTime(timezone=True), nullable=False)
    ship_from = Column(String(256), nullable=False)
    ship_to = Column(String(256), nullable=False)
    truck_number = Column(String(64), nullable=True)
    driver_name = Column(String(128), nullable=True)
    num_collies = Column(Integer, nullable=True)
    num_pallets = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)

    # Dynamic custom field values stored as JSON
    custom_data = Column(JSON, nullable=True, default=dict)

    # Audit
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    updated_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    created_by = relationship("User", foreign_keys=[created_by_id])
    updated_by = relationship("User", foreign_keys=[updated_by_id])
