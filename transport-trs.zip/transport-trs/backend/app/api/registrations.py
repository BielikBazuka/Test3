from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List

from app.core.database import get_db
from app.core.auth import get_current_user, require_admin
from app.models.user import User
from app.schemas.registration import RegistrationCreate, RegistrationUpdate, RegistrationOut
from app.services import registration_service as svc
from app.services.export_service import generate_excel

router = APIRouter(prefix="/registrations", tags=["registrations"])


@router.get("", response_model=List[RegistrationOut])
async def list_registrations(
    skip: int = 0,
    limit: int = Query(default=100, le=500),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    return await svc.list_registrations(db, skip=skip, limit=limit, search=search)


@router.post("", response_model=RegistrationOut, status_code=201)
async def create_registration(
    data: RegistrationCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await svc.create_registration(db, data, user)


# ── Export routes MUST come before /{reg_id} so FastAPI doesn't try to
#    parse "excel" or "csv" as an integer. ────────────────────────────────────

@router.get("/export/excel")
async def export_excel(
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    regs = await svc.list_registrations(db, limit=100_000)
    data = generate_excel(regs)
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=registrations.xlsx"},
    )


@router.get("/export/csv")
async def export_csv(
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    csv_data = await svc.export_to_csv(db)
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=registrations.csv"},
    )


# ── Single-record routes ─────────────────────────────────────────────────────

@router.get("/{reg_id}", response_model=RegistrationOut)
async def get_registration(
    reg_id: int,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    reg = await svc.get_registration(db, reg_id)
    if not reg:
        raise HTTPException(404, "Registration not found")
    return reg


@router.put("/{reg_id}", response_model=RegistrationOut)
async def update_registration(
    reg_id: int,
    data: RegistrationUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    reg = await svc.get_registration(db, reg_id)
    if not reg:
        raise HTTPException(404, "Registration not found")
    return await svc.update_registration(db, reg, data, user)


@router.delete("/{reg_id}", status_code=204)
async def delete_registration(
    reg_id: int,
    db: AsyncSession = Depends(get_db),
    _admin=Depends(require_admin),
):
    reg = await svc.get_registration(db, reg_id)
    if not reg:
        raise HTTPException(404, "Registration not found")
    await svc.delete_registration(db, reg)
