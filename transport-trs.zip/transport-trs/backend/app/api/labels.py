from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.auth import get_current_user
from app.models.user import User
from app.schemas.registration import LabelRequest
from app.services import registration_service as svc
from app.services.label_service import generate_pdf_labels, generate_zpl_labels

router = APIRouter(prefix="/labels", tags=["labels"])


@router.post("/generate")
async def generate_labels(
    req: LabelRequest,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    reg = await svc.get_registration(db, req.registration_id)
    if not reg:
        raise HTTPException(404, "Registration not found")

    num = max(1, min(req.num_labels, 50))  # cap at 50

    if req.format == "zpl":
        zpl = generate_zpl_labels(reg, num_labels=num)
        return Response(
            content=zpl,
            media_type="text/plain",
            headers={"Content-Disposition": f"attachment; filename={reg.trs_number}_labels.zpl"},
        )

    # Default: PDF
    pdf_bytes = generate_pdf_labels(reg, num_labels=num)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={reg.trs_number}_labels.pdf"},
    )
