from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List

from app.core.database import get_db
from app.core.auth import get_current_user, require_admin
from app.models.registration import CustomField
from app.schemas.registration import CustomFieldCreate, CustomFieldUpdate, CustomFieldOut

router = APIRouter(prefix="/fields", tags=["fields"])


@router.get("", response_model=List[CustomFieldOut])
async def list_fields(
    db: AsyncSession = Depends(get_db),
    _user=Depends(get_current_user),
):
    result = await db.execute(
        select(CustomField).where(CustomField.is_active == True).order_by(CustomField.order)
    )
    return result.scalars().all()


@router.get("/all", response_model=List[CustomFieldOut])
async def list_all_fields(
    db: AsyncSession = Depends(get_db),
    _admin=Depends(require_admin),
):
    result = await db.execute(select(CustomField).order_by(CustomField.order))
    return result.scalars().all()


@router.post("", response_model=CustomFieldOut, status_code=201)
async def create_field(
    data: CustomFieldCreate,
    db: AsyncSession = Depends(get_db),
    _admin=Depends(require_admin),
):
    existing = await db.execute(
        select(CustomField).where(CustomField.name == data.name)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(400, f"Field '{data.name}' already exists")
    field = CustomField(**data.model_dump())
    db.add(field)
    await db.commit()
    await db.refresh(field)
    return field


@router.put("/{field_id}", response_model=CustomFieldOut)
async def update_field(
    field_id: int,
    data: CustomFieldUpdate,
    db: AsyncSession = Depends(get_db),
    _admin=Depends(require_admin),
):
    result = await db.execute(select(CustomField).where(CustomField.id == field_id))
    field = result.scalar_one_or_none()
    if not field:
        raise HTTPException(404, "Field not found")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(field, k, v)
    await db.commit()
    await db.refresh(field)
    return field


@router.delete("/{field_id}", status_code=204)
async def delete_field(
    field_id: int,
    db: AsyncSession = Depends(get_db),
    _admin=Depends(require_admin),
):
    result = await db.execute(select(CustomField).where(CustomField.id == field_id))
    field = result.scalar_one_or_none()
    if not field:
        raise HTTPException(404, "Field not found")
    await db.delete(field)
    await db.commit()
