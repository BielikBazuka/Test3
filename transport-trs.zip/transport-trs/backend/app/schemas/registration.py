from pydantic import BaseModel
from typing import Optional, Any, List
from datetime import datetime


# ── Custom Fields ──────────────────────────────────────────────────────────────

class CustomFieldBase(BaseModel):
    label: str
    field_type: str = "text"
    options: Optional[list] = None
    required: bool = False
    order: int = 0
    is_active: bool = True


class CustomFieldCreate(CustomFieldBase):
    name: str  # must be unique, snake_case key


class CustomFieldUpdate(BaseModel):
    label: Optional[str] = None
    field_type: Optional[str] = None
    options: Optional[list] = None
    required: Optional[bool] = None
    order: Optional[int] = None
    is_active: Optional[bool] = None


class CustomFieldOut(CustomFieldBase):
    id: int
    name: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Registrations ──────────────────────────────────────────────────────────────

class RegistrationBase(BaseModel):
    arrival_timestamp: datetime
    ship_from: str
    ship_to: str
    truck_number: Optional[str] = None
    driver_name: Optional[str] = None
    num_collies: Optional[int] = None
    num_pallets: Optional[int] = None
    notes: Optional[str] = None
    custom_data: Optional[dict] = {}


class RegistrationCreate(RegistrationBase):
    pass


class RegistrationUpdate(BaseModel):
    arrival_timestamp: Optional[datetime] = None
    ship_from: Optional[str] = None
    ship_to: Optional[str] = None
    truck_number: Optional[str] = None
    driver_name: Optional[str] = None
    num_collies: Optional[int] = None
    num_pallets: Optional[int] = None
    notes: Optional[str] = None
    custom_data: Optional[dict] = None


class RegistrationOut(RegistrationBase):
    id: int
    trs_number: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by_id: Optional[int] = None

    model_config = {"from_attributes": True}


# ── Label Request ──────────────────────────────────────────────────────────────

class LabelRequest(BaseModel):
    registration_id: int
    num_labels: int = 1
    format: str = "pdf"  # "pdf" | "zpl"
