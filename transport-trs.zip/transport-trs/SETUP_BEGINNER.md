# TRS — Complete Setup Guide for Beginners

This guide assumes you have never used Git, Docker, or GitHub before.
Every step is explained in plain language. Follow in order — don't skip.

---

## What we're going to do

By the end of this guide you will have:

1. The TRS app running on **your own computer** (for testing)
2. The code **saved on GitHub** (so it's backed up and shareable)
3. The app running on a **server** so others in your team can use it
4. **Automatic deployment** — when you push code to GitHub, the server updates itself

---

## Concepts explained simply

**Docker** — Think of it as a box that contains the entire app (database, backend, frontend) with all its dependencies. You don't need to install Python, Node.js, or PostgreSQL directly — Docker handles all of that inside its boxes (called "containers").

**GitHub** — A website that stores your code online. It also has a feature called "Actions" that can automatically test and deploy your code whenever you make changes.

**Terminal / Command Prompt** — A text window where you type commands. On Windows it's called "Command Prompt" or "PowerShell". On Mac/Linux it's called "Terminal". We'll use it a lot.

**SSH** — A secure way to connect to a remote server and run commands on it, as if you were sitting in front of it.

---

## PHASE 1 — Install the tools on your computer

### Step 1 — Install Git

Git is how you track changes to code and upload it to GitHub.

**Windows:**
1. Go to https://git-scm.com/download/win
2. Download the installer (the big green button)
3. Run it, click **Next** through everything — defaults are fine
4. When done, open **Git Bash** from the Start menu (this is your terminal for the rest of this guide if you're on Windows)

**Mac:**
1. Open Terminal (press Cmd+Space, type "Terminal", press Enter)
2. Type this and press Enter:
   ```
   xcode-select --install
   ```
3. A popup appears — click **Install**. This installs Git along with developer tools.

**Linux (Ubuntu/Debian):**
```bash
sudo apt update && sudo apt install git -y
```

**Check it worked** — in your terminal, type:
```bash
git --version
```
You should see something like `git version 2.43.0`. Any version is fine.

---

### Step 2 — Install Docker Desktop

Docker Desktop runs all the containers (database, backend, frontend) for you.

**Windows and Mac:**
1. Go to https://www.docker.com/products/docker-desktop
2. Click the download button for your operating system
3. Run the installer
4. After installation, **restart your computer**
5. Open Docker Desktop from your Start menu / Applications folder
6. Wait for it to fully start (the whale icon in the taskbar/menu bar stops animating)

> ⚠️ Windows users: if you see a message about WSL 2, follow the link it gives you and install WSL 2 first. Then re-open Docker Desktop.

**Linux (Ubuntu):**
```bash
# Install Docker engine
curl -fsSL https://get.docker.com | sh

# Add yourself to the docker group (so you don't need "sudo" every time)
sudo usermod -aG docker $USER

# Apply the group change (or just log out and back in)
newgrp docker
```

**Check it worked:**
```bash
docker --version
docker compose version
```
You should see version numbers for both. If `docker compose` fails, try `docker-compose --version` (with a hyphen).

---

### Step 3 — Set up Git with your name and email

Git needs to know who you are when it saves changes. Run these two commands (replace with your real name and email):

```bash
git config --global user.name "Jan Kowalski"
git config --global user.email "jan.kowalski@example.com"
```

---

## PHASE 2 — Get the project files onto your computer

### Step 4 — Unzip the project

You received a file called `transport-trs.zip`. 

1. Move it to a good location — for example your **Documents** folder or **Desktop**
2. Unzip it:
   - **Windows:** Right-click → Extract All → choose a folder → Extract
   - **Mac:** Double-click the zip file
   - **Linux:** `unzip transport-trs.zip`

You now have a folder called `transport-trs`. Inside it you'll see folders like `backend/`, `frontend/`, and files like `docker-compose.yml`.

### Step 5 — Open a terminal in the project folder

**Windows (Git Bash):**
1. Open File Explorer
2. Navigate to the `transport-trs` folder
3. Right-click inside the folder → **Git Bash Here**

**Mac:**
1. Open Terminal
2. Type `cd ` (with a space after it), then drag the `transport-trs` folder into the Terminal window — it fills in the path automatically
3. Press Enter

**Linux:**
```bash
cd ~/Documents/transport-trs   # adjust path to wherever you unzipped it
```

**Check you're in the right folder:**
```bash
ls
```
You should see files like `docker-compose.yml`, `README.md`, folders `backend/` and `frontend/`. If you see something different, you're in the wrong folder.

---

## PHASE 3 — Configure and start the app locally

### Step 6 — Create your configuration file

The app needs a `.env` file with settings (passwords, secret keys, etc.). 
There's a template called `.env.example` — you'll copy it and edit it.

```bash
cp .env.example .env
```

On Windows Git Bash this is the same command. On Windows Command Prompt use:
```
copy .env.example .env
```

Now open `.env` in a text editor:
- **Windows:** `notepad .env`
- **Mac:** `open -e .env`
- **Linux:** `nano .env`

You'll see something like this:
```
DATABASE_URL=postgresql+asyncpg://trs:trs_password@db:5432/transport_trs
SECRET_KEY=change-me-to-a-long-random-string-in-production
...
```

**You must change the SECRET_KEY.** It's like a master password that protects all user sessions.

Generate a random key by running this command in your terminal:
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

> If `python3` is not found on Windows, try `python` instead.
> If neither works, you can use this website to generate one: https://generate-secret.vercel.app/64

Copy the output (a long string of letters and numbers like `a3f7b2...`) and replace `change-me-to-a-long-random-string-in-production` with it in the `.env` file.

**Save the file** (Ctrl+S or Cmd+S).

Leave everything else as-is for now. The database password in this file is only used locally on your computer.

---

### Step 7 — Start the app with Docker

Make sure Docker Desktop is open and running (whale icon visible in taskbar). Then run:

```bash
docker compose up -d
```

What `-d` means: "detached" — runs in the background so your terminal is free.

**First run takes 3–5 minutes** because Docker is downloading images and building the app. You'll see a lot of text scrolling by — that's normal.

When it finishes, check that everything is running:
```bash
docker compose ps
```

You should see three rows, all with status `running` or `Up`:
```
NAME                    STATUS
transport-trs-db-1      Up (healthy)
transport-trs-backend-1 Up
transport-trs-frontend-1 Up
```

If something shows `Exit` or `Restarting`, check the logs:
```bash
docker compose logs backend
docker compose logs frontend
```

---

### Step 8 — Open the app in your browser

Go to: **http://localhost:5173**

You should see the TRS login page with the ASML logo.

Login with:
- **Username:** `admin`
- **Password:** `changeme123`

You're in! You can now create registrations, print labels, manage users, etc.

> You can also see the API documentation at http://localhost:8000/docs — this is useful for developers but not required for day-to-day use.

**Change the admin password now:**
1. Click **Admin → Users** in the left sidebar
2. Click the edit icon next to `admin`
3. Enter a new strong password
4. Save

---

### Step 9 — Stop the app when you're done

```bash
docker compose down
```

This stops all containers but **keeps your data** (database entries, users, etc.).

To wipe everything and start completely fresh:
```bash
docker compose down -v
```

To start again later:
```bash
docker compose up -d
```

---

## PHASE 4 — Create a GitHub account and repository

### Step 10 — Create a GitHub account

If you don't have one:
1. Go to https://github.com
2. Click **Sign up**
3. Follow the steps — choose a username, enter your email, create a password
4. Verify your email address

### Step 11 — Create a new repository

A "repository" (or "repo") is a project on GitHub — think of it as a folder that GitHub watches.

1. Go to https://github.com and log in
2. Click the **+** icon in the top-right corner → **New repository**
3. Fill in:
   - **Repository name:** `transport-trs`
   - **Description:** `Transport Registration System`
   - **Visibility:** Private (this is an internal tool — keep it private)
4. **Important:** Do NOT tick any of the "Initialize this repository" checkboxes. Leave them all empty.
5. Click **Create repository**

GitHub will show you a page with setup instructions. Keep this page open — you'll need the URL in the next step.

---

### Step 12 — Connect your local project to GitHub

In your terminal (make sure you're still in the `transport-trs` folder):

```bash
git init
git add .
git commit -m "Initial commit"
```

What these do:
- `git init` — tells Git to start tracking this folder
- `git add .` — marks all files to be saved ("staged")
- `git commit -m "..."` — saves a snapshot with a description message

Now connect to GitHub. On the GitHub page you kept open, look for the section that says **"…or push an existing repository from the command line"**. It will show you two commands that look like this (with your actual username):

```bash
git remote add origin https://github.com/YOUR_USERNAME/transport-trs.git
git branch -M main
git push -u origin main
```

Run those three commands in your terminal.

GitHub will ask for your **username** and **password**. 

> ⚠️ **Important:** GitHub no longer accepts your regular password here. You need a Personal Access Token instead. See Step 13.

---

### Step 13 — Create a GitHub Personal Access Token (PAT)

A PAT is like a special password for command-line use.

1. Go to https://github.com/settings/tokens
2. Click **Generate new token** → **Generate new token (classic)**
3. Give it a name: `TRS local dev`
4. Set **Expiration** to `90 days` (or `No expiration` if you prefer)
5. Tick the checkbox for **`repo`** (this gives access to your repositories)
6. Click **Generate token** at the bottom
7. **Copy the token immediately** — GitHub will never show it again. Paste it in a safe place (like a password manager or a temporary text file).

Now when Git asks for your password in Step 12, paste this token instead of your GitHub password.

---

### Step 14 — Verify the code is on GitHub

Refresh the GitHub repository page. You should now see all your project files listed there (`.env.example`, `README.md`, `backend/`, `frontend/`, etc.).

Notice that `.env` is **not** there — that's correct. The `.gitignore` file tells Git to never upload `.env` because it contains passwords.

---

## PHASE 5 — Generate the package lock file

The automated CI pipeline needs a file called `package-lock.json` which records the exact versions of all JavaScript packages. Generate it once:

```bash
cd frontend
npm install
cd ..
```

> If `npm` is not found, you need to install Node.js from https://nodejs.org (download the LTS version). After installing, close and reopen your terminal, then try again.

Now save this file to GitHub:
```bash
git add frontend/package-lock.json
git commit -m "Add package lock file"
git push
```

---

## PHASE 6 — Set up a server (skip this if you only need it locally)

This phase sets up the app on a server so your whole team can use it from any computer. If you just need it on your own machine for now, skip to the **Troubleshooting** section at the bottom.

### Step 15 — Get a server

You need a Linux server (Ubuntu 22.04 or 24.04 recommended). Options:

| Provider | Cheapest option | Notes |
|----------|----------------|-------|
| Hetzner | ~€4/month (CX22) | Best value, European data centers |
| DigitalOcean | ~$6/month (Droplet) | Easy to use |
| Azure / AWS | Varies | May already have credits at ASML |
| Your own machine | Free | As long as it's always on and reachable |

When you create the server, choose **Ubuntu 22.04** or **Ubuntu 24.04**. Note down:
- The server's **IP address** (e.g. `194.15.23.87`)
- The **username** (usually `root` or `ubuntu` depending on provider)

### Step 16 — Connect to your server via SSH

SSH lets you control your server from your terminal as if you were sitting in front of it.

**First, check if you have an SSH key** (a pair of files that prove your identity):
```bash
ls ~/.ssh/id_ed25519
```

If it says "No such file or directory", create one:
```bash
ssh-keygen -t ed25519 -C "your-email@example.com"
```
Press **Enter** three times (accept default location, no passphrase).

This creates two files:
- `~/.ssh/id_ed25519` — your **private key** (never share this)
- `~/.ssh/id_ed25519.pub` — your **public key** (safe to share)

**Add your public key to the server.** Your server provider usually lets you add SSH keys during setup. If not, do it now:

```bash
# Show your public key and copy the output
cat ~/.ssh/id_ed25519.pub
```

Log into your server provider's web dashboard, find the SSH keys section, and paste the public key there. Or if you can already SSH with a password:

```bash
ssh-copy-id username@YOUR_SERVER_IP
```

**Now connect:**
```bash
ssh username@YOUR_SERVER_IP
```

Replace `username` with `root` or `ubuntu` (check your provider) and `YOUR_SERVER_IP` with the actual IP.

Type `yes` when asked about the fingerprint. You're now inside your server — the terminal prompt will change.

---

### Step 17 — Install Docker on the server

You're now running commands ON the server (not your local machine). Run:

```bash
# Update package lists
sudo apt update

# Install Docker
curl -fsSL https://get.docker.com | sh

# Add your user to the docker group
sudo usermod -aG docker $USER

# Apply group change without logging out
newgrp docker

# Verify Docker works
docker --version
docker compose version
```

---

### Step 18 — Create the app folder on the server

```bash
sudo mkdir -p /opt/transport-trs
sudo chown $USER:$USER /opt/transport-trs
cd /opt/transport-trs
```

---

### Step 19 — Create the production config file on the server

```bash
nano /opt/transport-trs/.env
```

Nano is a simple text editor. Paste the following (press Ctrl+Shift+V to paste in most terminals):

```env
DATABASE_URL=postgresql+asyncpg://trs:CHANGE_THIS_PASSWORD@db:5432/transport_trs
DB_USER=trs
DB_PASSWORD=CHANGE_THIS_PASSWORD
DB_NAME=transport_trs

SECRET_KEY=PASTE_YOUR_GENERATED_KEY_HERE
ACCESS_TOKEN_EXPIRE_MINUTES=480
APP_ENV=production
BACKEND_CORS_ORIGINS=["http://YOUR_SERVER_IP_HERE"]

LABEL_WIDTH_MM=62
LABEL_HEIGHT_MM=29
LABEL_PRINTER_DPI=300
```

Replace:
- `CHANGE_THIS_PASSWORD` — use a strong password (same value in both places)
- `PASTE_YOUR_GENERATED_KEY_HERE` — generate one: `python3 -c "import secrets; print(secrets.token_hex(32))"`
- `YOUR_SERVER_IP_HERE` — your server's actual IP address

**Save and exit nano:** press **Ctrl+X**, then **Y**, then **Enter**.

---

### Step 20 — Copy the production Docker Compose file to the server

Back on **your local machine** (open a new terminal or type `exit` to leave the server), run:

```bash
scp docker-compose.prod.yml username@YOUR_SERVER_IP:/opt/transport-trs/
```

This copies the file from your computer to the server.

---

## PHASE 7 — Set up automatic deployment (GitHub Actions)

Every time you push code to the `main` branch on GitHub, the pipeline will automatically:
1. Run tests
2. Build new Docker images
3. Push them to GitHub's container registry
4. SSH into your server and update the running app

### Step 21 — Create an SSH key for GitHub to use

This is a separate key just for deployment — GitHub needs it to SSH into your server automatically.

On your **local machine**:
```bash
ssh-keygen -t ed25519 -C "github-actions-deploy" -f ~/.ssh/trs_deploy
```
Press Enter twice (no passphrase).

**Add the public key to the server** so GitHub can log in:
```bash
# Show the public key
cat ~/.ssh/trs_deploy.pub
```
Copy the output. Now SSH into your server and add it:
```bash
ssh username@YOUR_SERVER_IP
echo "PASTE_THE_PUBLIC_KEY_HERE" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
exit
```

**Copy the private key** — you'll need to paste it into GitHub:
```bash
cat ~/.ssh/trs_deploy
```
Copy the ENTIRE output, including the lines `-----BEGIN OPENSSH PRIVATE KEY-----` and `-----END OPENSSH PRIVATE KEY-----`.

---

### Step 22 — Add secrets to GitHub

GitHub Secrets are encrypted variables that the automated pipeline can use without exposing them in your code.

1. Go to your GitHub repository page
2. Click **Settings** (the tab with a gear icon, at the top of the repo page)
3. In the left sidebar, click **Secrets and variables** → **Actions**
4. Click **New repository secret**

Add these secrets one by one (click "New repository secret" for each):

| Secret Name | What to paste |
|-------------|--------------|
| `DEPLOY_HOST` | Your server's IP address (e.g. `194.15.23.87`) |
| `DEPLOY_USER` | Your server username (`root` or `ubuntu`) |
| `DEPLOY_SSH_KEY` | The entire private key you copied from `~/.ssh/trs_deploy` |
| `DEPLOY_PATH` | `/opt/transport-trs` |

For each one: type the name exactly as shown, paste the value, click **Add secret**.

---

### Step 23 — Allow GitHub to push Docker images

GitHub needs permission to store Docker images in its container registry.

1. Go to your **GitHub profile** → click your avatar top-right → **Settings**
2. In the left sidebar, scroll down to **Developer settings** → **Personal access tokens** → **Tokens (classic)**
3. Click **Generate new token (classic)**
4. Name: `TRS deployment`
5. Tick: `write:packages` and `read:packages`
6. Click **Generate token**
7. Copy the token

Now go back to your **repository settings**:
1. Settings → Secrets and variables → Actions → **New repository secret**
2. Name: `CR_PAT`
3. Value: paste the token you just copied
4. Click **Add secret**

> **Note:** The default `GITHUB_TOKEN` in Actions can push images, but you need the `CR_PAT` only if you get authentication errors. The workflow is set up to try without it first.

---

### Step 24 — Trigger your first automated deployment

Make a tiny change to trigger the pipeline. In your terminal on your local machine:

```bash
# Make sure you're in the transport-trs folder
echo "# TRS" >> README.md
git add README.md
git commit -m "Trigger first deployment"
git push
```

Now watch it run:
1. Go to your GitHub repository
2. Click the **Actions** tab at the top
3. You'll see a workflow run appear — click on it to watch it live

The pipeline runs these stages (each shown as a box):
- **Backend Tests** — runs unit tests (~1 minute)
- **Frontend Build** — builds the Vue app (~1 minute)
- **Build Docker Images** — builds and pushes images to GitHub (~3 minutes)
- **Deploy to Production** — SSHes into your server and restarts the app (~30 seconds)

Green checkmarks = success. Red X = something failed, click on it to see the error.

---

### Step 25 — First manual pull on the server

The very first time, you need to manually log in to GitHub's container registry from your server. SSH into your server:

```bash
ssh username@YOUR_SERVER_IP
```

Log in to GitHub's Docker registry (use your GitHub username and the PAT you created earlier):
```bash
echo YOUR_GITHUB_PAT | docker login ghcr.io -u YOUR_GITHUB_USERNAME --password-stdin
```

Pull and start the app:
```bash
cd /opt/transport-trs
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d
```

**The app is now live at: http://YOUR_SERVER_IP**

After this first manual step, all future deployments happen automatically when you push to GitHub. You never need to SSH in again unless something goes wrong.

---

## PHASE 8 — Daily use

### How to make a change and deploy it

```bash
# 1. Make your changes (edit files, fix bugs, add features)

# 2. Save the changes
git add .
git commit -m "Describe what you changed"

# 3. Upload to GitHub (triggers automatic deployment)
git push
```

That's it. GitHub Actions does the rest.

### How to add a new user

1. Open the app in your browser
2. Log in as admin
3. Click **Admin → Users** in the sidebar
4. Click **+ Add User**
5. Fill in username, name, and a temporary password
6. Set role: `user` (regular) or `admin` (full access)
7. Tell the new user their credentials — they can change their password after first login

### How to export data

In the Registrations list:
- Click **⬇ CSV** to download a spreadsheet-compatible file
- Click **⬇ Excel** to download a formatted .xlsx file

### How to print labels

1. Find the registration in the list
2. Click the 🏷 icon in the Actions column
3. Choose:
   - **Number of labels** (1–50)
   - **Format:** PDF (works with any printer) or ZPL (for Zebra label printers)
4. Click **Generate**
5. A PDF opens in a new browser tab → press **Ctrl+P** (or Cmd+P on Mac) to print

---

## Troubleshooting

### "Cannot connect to Docker daemon"
Docker Desktop isn't running. Open Docker Desktop and wait for it to fully start (the whale icon stops animating).

### "Port 5173 is already in use" or "Port 8000 is already in use"
Another program is using that port. Either stop the other program, or:
```bash
docker compose down
docker compose up -d
```

### App shows login page but login fails
Check the backend is running:
```bash
docker compose logs backend
```
If you see database errors, the database may still be starting. Wait 30 seconds and try again.

### "git push" asks for username and password every time
Store your credentials so you don't have to type them repeatedly:
```bash
git config --global credential.helper store
```
Then push once and enter your username + PAT. It will remember them after that.

### GitHub Actions fails on "Backend Tests"
Click the failed job in GitHub Actions and read the error message. Common causes:
- The test database couldn't start — usually fixes itself on retry
- A Python import error — check that all files were committed

### GitHub Actions fails on "npm ci"
The `package-lock.json` is missing. Fix it:
```bash
cd frontend
npm install
cd ..
git add frontend/package-lock.json
git commit -m "Add package-lock.json"
git push
```

### App works locally but not on server
Check server logs:
```bash
ssh username@YOUR_SERVER_IP
cd /opt/transport-trs
docker compose -f docker-compose.prod.yml logs backend
docker compose -f docker-compose.prod.yml logs frontend
```

Common cause: the `.env` file on the server has wrong values. Double-check `DATABASE_URL`, `DB_PASSWORD`, and `BACKEND_CORS_ORIGINS`.

### "Permission denied" when running Docker commands on Linux
You haven't been added to the docker group yet:
```bash
sudo usermod -aG docker $USER
newgrp docker
```

---

## Quick command reference

| What you want to do | Command (in project folder) |
|--------------------|-----------------------------|
| Start app locally | `docker compose up -d` |
| Stop app locally | `docker compose down` |
| Restart everything | `docker compose down && docker compose up -d` |
| Wipe local data and restart | `docker compose down -v && docker compose up -d` |
| Watch backend logs | `docker compose logs -f backend` |
| Watch all logs | `docker compose logs -f` |
| Save and upload changes | `git add . && git commit -m "your message" && git push` |
| Check what files changed | `git status` |
| See recent commits | `git log --oneline` |

---

## Glossary

| Word | What it means |
|------|--------------|
| Container | A lightweight isolated environment that runs a piece of software |
| Docker | Software that creates and manages containers |
| Docker Compose | A tool to run multiple containers together |
| Git | Software that tracks changes to code |
| GitHub | Website that stores Git repositories online |
| Repository (repo) | A project folder tracked by Git |
| Commit | A saved snapshot of your code at a point in time |
| Push | Upload your local commits to GitHub |
| Pull | Download changes from GitHub to your computer |
| SSH | Secure Shell — encrypted connection to a remote server |
| SSH Key | A pair of files (public + private) used to prove identity over SSH |
| Personal Access Token (PAT) | A password substitute for GitHub command-line access |
| CI/CD | Continuous Integration / Continuous Deployment — automated testing and deployment |
| GitHub Actions | GitHub's built-in CI/CD system |
| Environment variable | A setting stored outside the code (in the `.env` file) |
| `.env` file | A file containing secret settings — never committed to Git |
| GHCR | GitHub Container Registry — where Docker images are stored |
| nginx | A web server that serves the frontend and forwards API requests |
